TrayUP combined archive
=======================

This archive contains all seven ZIP snapshots uploaded in this conversation.

Contents:
1. TrayUP-Merged/TrayUP-main/
   A unified working tree. v5.zip is the base. Files that exist only in earlier
   snapshots are added without replacing v5 files. For a path present in v5 and
   an older snapshot, the v5 version is used in this working tree.

2. source_snapshots/
   Full extracted copies of every uploaded ZIP, preserving each snapshot's
   original project paths and file contents. Use these to retrieve any older
   version or inspect differences. No source file in these snapshots was edited.

3. MERGE_MANIFEST.csv
   SHA-256 hashes, file sizes, source archive and source path for every file
   in each original snapshot. This makes source provenance checkable.

Merge summary:
- Uploaded ZIP snapshots: 7
- Files in v5 snapshot: 178
- Unique paths in unified tree: 230
- Paths with differing contents between v5 and at least one earlier snapshot: 98
- Files copied unchanged into source_snapshots: 1182

Important:
This is a file-level merge, not an integration of application logic. The v5
version wins when the same path differs; older alternatives remain in their
original snapshot folders. Older-only files are included in the unified tree,
but may depend on other files or migrations from their original snapshot.
No application source code was intentionally modified, reformatted or fixed.
