(function () {
  const nav = [["Overview", "dashboard.html"], ["Menu", "menu.html"], ["Categories", "categories.html"], ["Orders", "orders.html"], ["Staff", "staff.html"], ["Reports", "reports.html"], ["Refunds", "refunds.html"], ["Settings", "settings.html"]];
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = (paise) => "₹" + (Number(paise || 0) / 100).toLocaleString("en-IN", { maximumFractionDigits: 2 });
  const LABELS = {
    pending_payment: "Awaiting payment", received: "Received", preparing: "Preparing", ready: "Ready",
    collected: "Collected", cancelled: "Cancelled", pending: "Pending", paid: "Paid", failed: "Failed",
    refunded: "Refunded", partially_refunded: "Partially refunded"
  };
  const label = (value) => LABELS[value] || value || "—";
  const statsEl = () => document.getElementById("admin-stats");
  const ordersEl = () => document.getElementById("admin-orders");

  document.getElementById("admin-nav").innerHTML = nav.map(([name, file]) =>
    '<a class="' + (file === "dashboard.html" ? "active" : "") + '" href="./' + file + '">' + esc(name) + "</a>"
  ).join("");

  // Today's date in the browser's local calendar. Reports group orders by the canteen's day.
  function todayIso() {
    const d = new Date();
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
  }

  function renderStats(cards) {
    statsEl().innerHTML = cards.map(([name, value]) =>
      '<div class="admin-card"><span>' + esc(name) + '</span><div class="value">' + esc(value) + "</div></div>"
    ).join("");
  }

  function renderRecent(orders) {
    ordersEl().innerHTML = orders.length ? orders.map(order =>
      "<tr><td>" + esc(order.order_number) +
      "</td><td>" + esc(order.student ? order.student.name : "Guest") +
      "</td><td>" + money(order.total_paise) +
      '</td><td><span class="status">' + esc(label(order.order_status)) + "</span></td><td>" +
      esc(label(order.payment_status)) + "</td></tr>"
    ).join("") : '<tr><td colspan="5">No orders yet</td></tr>';
  }

  function showError(message, signIn) {
    statsEl().innerHTML = '<div class="admin-card"><span>' + esc(message) + "</span>" +
      (signIn ? '<div class="value" style="font-size:18px"><a href="./login.html">Sign in</a></div>' : "") + "</div>";
    ordersEl().textContent = message;
  }

  async function load() {
    try {
      // Every number comes from the server, so it covers all orders, not just one page.
      const today = todayIso();
      const [overview, recent, received, preparing, ready] = await Promise.all([
        trayApi.get("/admin/reports/overview?from=" + today + "&to=" + today),
        trayApi.get("/admin/orders?per_page=8"),
        trayApi.get("/admin/orders?per_page=1&order_status=received"),
        trayApi.get("/admin/orders?per_page=1&order_status=preparing"),
        trayApi.get("/admin/orders?per_page=1&order_status=ready")
      ]);

      const figures = overview.data;
      const inKitchen = received.data.pagination.total + preparing.data.pagination.total + ready.data.pagination.total;
      renderStats([
        ["Orders today", figures.total_orders],
        ["Paid today", figures.paid_orders],
        ["Net revenue today", money(figures.net_revenue_paise)],
        ["In the kitchen now", inKitchen]
      ]);
      renderRecent(recent.data.orders || []);
    } catch (error) {
      showError(error.status === 401 ? "Please sign in to view administrator data." :
        error.status === 403 ? "This account does not have administrator access." :
        "Unable to load administrator data. Please retry.", error.status === 401 || error.status === 403);
    }
  }

  document.getElementById("logout").addEventListener("click", async () => {
    try { await trayAuth.logout(); } catch (_) {}
    location.href = "./login.html";
  });

  load();
})();
