(function () {
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);

  const body = document.getElementById("staff-body");
  const status = document.getElementById("staff-status");
  const ROLE_LABELS = { ADMIN: "Admin", KITCHEN: "Kitchen" };
  let staff = [];

  // Errors from the API: validation problems list each field, otherwise show the message.
  function describe(error) {
    const details = error?.data?.details;
    if (details && typeof details === "object") return Object.values(details).join(" ");
    if (error?.status === 403) return "This account does not have administrator access.";
    return error?.message || "Something went wrong. Please retry.";
  }

  function findStaff(id) {
    return staff.find((member) => member.id === Number(id));
  }

  function render() {
    if (!staff.length) {
      body.innerHTML = '<tr><td colspan="5">No staff accounts yet.</td></tr>';
      return;
    }
    body.innerHTML = staff.map((member) => `<tr>` +
      `<td><strong>${esc(member.name)}</strong></td>` +
      `<td>${esc(member.email)}</td>` +
      `<td>${esc(ROLE_LABELS[member.role] || member.role)}</td>` +
      `<td><span class="status ${member.is_active ? "" : "danger"}">${member.is_active ? "Active" : "Inactive"}</span></td>` +
      `<td>` +
        `<button class="btn btn-secondary" data-role="${esc(member.id)}" type="button">Change role</button> ` +
        `<button class="btn btn-secondary" data-password="${esc(member.id)}" type="button">Reset password</button> ` +
        `<button class="btn btn-secondary" data-toggle="${esc(member.id)}" type="button">${member.is_active ? "Deactivate" : "Activate"}</button>` +
      `</td></tr>`).join("");
  }

  async function load() {
    try {
      const response = await trayApi.get("/admin/staff");
      staff = response.data.staff || [];
      render();
    } catch (error) {
      body.innerHTML = '<tr><td colspan="5">Unable to load staff accounts.</td></tr>';
      status.textContent = describe(error);
    }
  }

  async function update(member, payload, successMessage) {
    try {
      const response = await trayApi.patch(`/admin/staff/${member.id}`, payload);
      const saved = response.data;
      const index = staff.findIndex((row) => row.id === saved.id);
      if (index !== -1) staff[index] = saved;
      render();
      trayNotify(successMessage);
    } catch (error) {
      trayNotify(describe(error));
    }
  }

  // Accepts "Admin" or "Kitchen" in any case and returns the API role name.
  function parseRole(text) {
    const cleaned = String(text || "").trim().toUpperCase();
    return cleaned === "ADMIN" || cleaned === "KITCHEN" ? cleaned : null;
  }

  document.getElementById("add-staff").addEventListener("click", async () => {
    const name = prompt("Staff name");
    if (!name || !name.trim()) return;
    const email = prompt("Login email address");
    if (!email || !email.trim()) return;
    const roleText = prompt("Role: type Admin or Kitchen", "Kitchen");
    if (roleText === null) return;
    const role = parseRole(roleText);
    if (!role) { trayNotify("Role must be Admin or Kitchen."); return; }
    const password = prompt("Temporary password (at least 8 characters, with a letter and a number)");
    if (!password) return;

    try {
      const response = await trayApi.post("/admin/staff", {
        name: name.trim(), email: email.trim(), role, password,
      });
      staff.push(response.data);
      staff.sort((a, b) => a.name.localeCompare(b.name));
      render();
      trayNotify("Staff account created");
    } catch (error) {
      trayNotify(describe(error));
    }
  });

  body.addEventListener("click", (event) => {
    const roleButton = event.target.closest("[data-role]");
    const passwordButton = event.target.closest("[data-password]");
    const toggleButton = event.target.closest("[data-toggle]");

    if (roleButton) {
      const member = findStaff(roleButton.dataset.role);
      if (!member) return;
      const roleText = prompt("Role: type Admin or Kitchen", ROLE_LABELS[member.role] || "Kitchen");
      if (roleText === null) return;
      const role = parseRole(roleText);
      if (!role) { trayNotify("Role must be Admin or Kitchen."); return; }
      if (role !== member.role) update(member, { role }, "Role updated");
    }

    if (passwordButton) {
      const member = findStaff(passwordButton.dataset.password);
      if (!member) return;
      const password = prompt(`New password for ${member.name} (at least 8 characters, with a letter and a number)`);
      if (!password) return;
      update(member, { password }, "Password reset. Share it with the staff member securely.");
    }

    if (toggleButton) {
      const member = findStaff(toggleButton.dataset.toggle);
      if (!member) return;
      update(member, { is_active: !member.is_active },
        member.is_active ? "Account deactivated" : "Account activated");
    }
  });

  load();
})();
