(function () {
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);

  const body = document.getElementById("menu-body");
  const status = document.getElementById("menu-status");
  let items = [];

  // Errors from the API: validation problems list each field, otherwise show the message.
  function describe(error) {
    const details = error?.data?.details;
    if (details && typeof details === "object") return Object.values(details).join(" ");
    return error?.message || "Something went wrong. Please retry.";
  }

  const rupees = (paise) => (Number(paise || 0) / 100).toLocaleString("en-IN", { maximumFractionDigits: 2 });

  function findItem(id) {
    return items.find((item) => item.id === Number(id));
  }

  function render() {
    if (!items.length) {
      body.innerHTML = '<tr><td colspan="5">No menu items yet. Use “Add item” to create one.</td></tr>';
      return;
    }
    body.innerHTML = items.map((item) => {
      const stock = item.stock_quantity === null || item.stock_quantity === undefined
        ? ""
        : `<br><small class="muted">${Number(item.available_quantity ?? 0)} of ${Number(item.stock_quantity)} left</small>`;
      return `<tr>` +
        `<td><strong>${esc(item.name)}</strong></td>` +
        `<td>${esc(item.category)}</td>` +
        `<td>₹${rupees(item.price_paise)}</td>` +
        `<td><span class="status ${item.is_available ? "" : "danger"}">${item.is_available ? "Available" : "Unavailable"}</span>${stock}</td>` +
        `<td>` +
          `<button class="btn btn-secondary" data-edit="${esc(item.id)}" type="button">Edit</button> ` +
          `<button class="btn btn-secondary" data-toggle="${esc(item.id)}" type="button">${item.is_available ? "Disable" : "Enable"}</button>` +
        `</td></tr>`;
    }).join("");
  }

  async function load() {
    try {
      const response = await trayApi.get("/admin/menu");
      items = response.items || [];
      render();
    } catch (error) {
      body.innerHTML = '<tr><td colspan="5">Unable to load menu items.</td></tr>';
      status.textContent = error.status === 403 ? "This account does not have administrator access." : describe(error);
    }
  }

  // Money is entered in rupees and stored as whole paise, so there is no floating-point rounding.
  function parseRupees(text) {
    const value = Number(String(text).trim());
    if (!Number.isFinite(value) || value < 0) return null;
    return Math.round(value * 100);
  }

  async function save(path, method, payload, successMessage) {
    try {
      const response = method === "POST"
        ? await trayApi.post(path, payload)
        : await trayApi.patch(path, payload);
      const saved = response.item;
      const index = items.findIndex((item) => item.id === saved.id);
      if (index === -1) items.push(saved); else items[index] = saved;
      items.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
      render();
      trayNotify(successMessage);
    } catch (error) {
      trayNotify(describe(error));
    }
  }

  document.getElementById("add-item").addEventListener("click", () => {
    const name = prompt("Item name");
    if (!name || !name.trim()) return;
    const category = prompt("Category (for example Snacks, Breakfast, Meals)", "Snacks");
    if (!category || !category.trim()) return;
    const priceText = prompt("Price in rupees", "100");
    if (priceText === null) return; // cancelled
    const price = parseRupees(priceText);
    if (price === null) { trayNotify("Enter a price of zero or more."); return; }
    save("/admin/menu", "POST", {
      name: name.trim(),
      category: category.trim(),
      price_paise: price,
      is_available: true,
    }, "Menu item added");
  });

  body.addEventListener("click", (event) => {
    const edit = event.target.closest("[data-edit]");
    const toggle = event.target.closest("[data-toggle]");

    if (edit) {
      const item = findItem(edit.dataset.edit);
      if (!item) return;
      const name = prompt("Item name", item.name);
      if (!name || !name.trim()) return;
      const category = prompt("Category", item.category);
      if (!category || !category.trim()) return;
      const priceText = prompt("Price in rupees", (item.price_paise / 100).toString());
      if (priceText === null) return; // cancelled
      const price = parseRupees(priceText);
      if (price === null) { trayNotify("Enter a price of zero or more."); return; }
      save(`/admin/menu/${item.id}`, "PATCH", {
        name: name.trim(),
        category: category.trim(),
        price_paise: price,
      }, "Menu item updated");
    }

    if (toggle) {
      const item = findItem(toggle.dataset.toggle);
      if (!item) return;
      save(`/admin/menu/${item.id}`, "PATCH", { is_available: !item.is_available },
        item.is_available ? "Item hidden from students" : "Item available to students");
    }
  });

  load();
})();
