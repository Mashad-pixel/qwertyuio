(function () {
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);

  const PAGE_SIZE = 20;
  const LABELS = {
    pending_payment: "Awaiting payment", received: "Received", preparing: "Preparing",
    ready: "Ready", collected: "Collected", cancelled: "Cancelled",
    pending: "Pending", paid: "Paid", failed: "Failed",
    refunded: "Refunded", partially_refunded: "Partially refunded"
  };

  const $ = (id) => document.getElementById(id);
  const body = $("orders-body");
  const state = { page: 1, pages: 1, requestId: 0, searchTimer: null };

  const label = (value) => LABELS[value] || value || "—";
  const money = (paise) => "₹" + (Number(paise || 0) / 100).toLocaleString("en-IN", { maximumFractionDigits: 2 });
  const placed = (iso) => (iso ? new Date(iso).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "—");

  function queryString() {
    // Filters are sent to the server so paging and totals match what the admin sees.
    const params = new URLSearchParams({ page: String(state.page), per_page: String(PAGE_SIZE) });
    const search = $("order-search").value.trim();
    if (search) params.set("q", search);
    if ($("status-filter").value) params.set("order_status", $("status-filter").value);
    if ($("payment-filter").value) params.set("payment_status", $("payment-filter").value);
    return params.toString();
  }

  function renderRows(orders) {
    if (!orders.length) {
      body.innerHTML = '<tr><td colspan="6">No matching orders</td></tr>';
      return;
    }
    body.innerHTML = orders.map((order) => {
      const student = order.student
        ? `${esc(order.student.name)}<br><small class="muted">${esc(order.student.email)}</small>`
        : "—";
      return `<tr>` +
        `<td><strong>${esc(order.order_number)}</strong></td>` +
        `<td>${student}</td>` +
        `<td>${money(order.total_paise)}</td>` +
        `<td><span class="status">${esc(label(order.order_status))}</span></td>` +
        `<td>${esc(label(order.payment_status))}</td>` +
        `<td>${esc(placed(order.created_at))}</td>` +
        `</tr>`;
    }).join("");
  }

  function renderPager(pagination) {
    state.pages = Math.max(pagination.pages || 1, 1);
    $("pager-info").textContent = `${pagination.total} order${pagination.total === 1 ? "" : "s"} · page ${pagination.page} of ${state.pages}`;
    $("prev-page").disabled = !pagination.has_prev;
    $("next-page").disabled = !pagination.has_next;
  }

  async function load() {
    const requestId = ++state.requestId;
    body.innerHTML = '<tr><td colspan="6">Loading…</td></tr>';
    try {
      const response = await trayApi.get(`/admin/orders?${queryString()}`);
      if (requestId !== state.requestId) return; // a newer request has already been made
      renderRows(response.data.orders || []);
      renderPager(response.data.pagination);
    } catch (error) {
      if (requestId !== state.requestId) return;
      body.textContent = error.status === 401 ? "Please sign in to view administrator orders."
        : error.status === 403 ? "This account does not have administrator access."
        : error.status === 400 ? (error.message || "Those filters are not valid.")
        : "Unable to load orders. Please retry.";
    }
  }

  function filtersChanged() {
    state.page = 1;
    load();
  }

  $("order-search").addEventListener("input", () => {
    clearTimeout(state.searchTimer);
    state.searchTimer = setTimeout(filtersChanged, 300);
  });
  $("status-filter").addEventListener("change", filtersChanged);
  $("payment-filter").addEventListener("change", filtersChanged);
  $("prev-page").addEventListener("click", () => { if (state.page > 1) { state.page -= 1; load(); } });
  $("next-page").addEventListener("click", () => { if (state.page < state.pages) { state.page += 1; load(); } });

  load();
})();
