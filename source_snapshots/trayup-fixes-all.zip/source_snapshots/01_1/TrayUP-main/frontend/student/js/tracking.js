(function () {
  document.getElementById("app-header").innerHTML = trayComponents.header("My Orders");

  const PER_PAGE = 10;
  const ORDER_STATUS = {
    pending_payment: "Awaiting payment", received: "Received", preparing: "Preparing",
    ready: "Ready for collection", collected: "Collected", cancelled: "Cancelled"
  };
  const PAYMENT_STATUS = { pending: "Pending", paid: "Paid", failed: "Failed", refunded: "Refunded", partially_refunded: "Partially refunded" };

  const target = document.getElementById("tracking");
  const state = { orders: [], page: 0, hasNext: false, imageById: new Map(), requestId: 0 };
  const ordersById = new Map();

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
    })[character]);
  }
  const money = (paise) => "₹" + (Number(paise || 0) / 100).toLocaleString("en-IN", { maximumFractionDigits: 2 });
  const placed = (iso) => (iso ? new Date(iso).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "");

  function statusClass(status) {
    if (status === "cancelled") return "danger";
    if (status === "collected") return "";
    return "warning";
  }

  // The server's order shape: order_number, order_status, payment_status, total_paise,
  // created_at, and items[] with item_name, menu_item_id, quantity, unit_price_paise, line_total_paise.
  function orderCard(order) {
    const items = Array.isArray(order.items) ? order.items : [];
    const orderNumber = escapeHtml(order.order_number);
    const cancelled = order.order_status === "cancelled";
    const paid = order.payment_status === "paid";
    const completed = order.order_status === "collected";

    const slides = items.map((item) => {
      const image = state.imageById.get(item.menu_item_id) || "";
      return `
                <div class="order-food-slide">
                  <div>
                    <strong>${escapeHtml(item.item_name)}</strong>
                    <p>Qty ${Number(item.quantity) || 1} · ${money(item.unit_price_paise)} each</p>
                    <strong>Item total: ${money(item.line_total_paise)}</strong>
                  </div>
                  ${image ? `<img src="${escapeHtml(image)}" alt="${escapeHtml(item.item_name)}" onerror="this.style.display='none'">` : ""}
                </div>`;
    }).join("");

    return `
        <article class="card" style="margin-bottom:14px;padding:18px" data-order="${orderNumber}">
          <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
            <div>
              <strong class="receipt-order-number">Receipt ${orderNumber}</strong>
              <p style="color:var(--muted);font-size:13px;margin-top:5px">${items.length} item${items.length === 1 ? "" : "s"} · ${money(order.total_paise)}</p>
            </div>
            <span class="status ${statusClass(order.order_status)}">${escapeHtml(ORDER_STATUS[order.order_status] || order.order_status)}</span>
          </div>
          <div class="order-progress order-progress-compact" aria-label="Order progress">
            <div class="progress-step complete"><span class="progress-circle"></span><span>Placed</span></div>
            <div class="progress-step ${paid ? "complete" : "active"}"><span class="progress-circle"></span><span>Payment</span></div>
            <div class="progress-step ${completed ? "complete" : ""}"><span class="progress-circle"></span><span>Collected</span></div>
          </div>
          <div class="order-food-carousel">
            <div class="order-food-track" tabindex="0" aria-label="Ordered foods; swipe horizontally to view each item">${slides}
            </div>
            ${items.length > 1 ? `
              <div class="order-carousel-controls">
                <button type="button" data-carousel-prev aria-label="Previous food">‹</button>
                <span aria-live="polite"><span data-carousel-current>1</span> / ${items.length}</span>
                <button type="button" data-carousel-next aria-label="Next food">›</button>
              </div>` : ""}
          </div>
          <div class="order-details" hidden style="border-top:1px solid #eee;padding-top:12px;color:var(--muted);font-size:13px">
            ${placed(order.created_at) ? `Placed ${escapeHtml(placed(order.created_at))} · ` : ""}Payment ${escapeHtml(PAYMENT_STATUS[order.payment_status] || order.payment_status)} · Total ${money(order.total_paise)}
          </div>
          <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px">
            <button class="btn btn-secondary" type="button" data-view="${orderNumber}">View Details</button>
            <button class="btn btn-primary" type="button" data-reorder="${orderNumber}" ${cancelled || !items.length ? "disabled" : ""}>Reorder</button>
          </div>
        </article>`;
  }

  function renderAll() {
    ordersById.clear();
    state.orders.forEach((order) => ordersById.set(String(order.order_number), order));
    if (!state.orders.length) {
      target.innerHTML = '<div class="empty-state"><h3>No orders yet</h3><p>Orders you place will appear here.</p></div>';
      return;
    }
    target.innerHTML = state.orders.map(orderCard).join("") +
      (state.hasNext ? '<div style="text-align:center;margin-top:10px"><button class="btn btn-secondary" type="button" id="load-more">Load more orders</button></div>' : "");
    target.querySelectorAll(".order-food-track").forEach((track) => {
      track.addEventListener("scroll", () => {
        const current = track.closest(".order-food-carousel").querySelector("[data-carousel-current]");
        if (current) current.textContent = String(Math.round(track.scrollLeft / track.clientWidth) + 1);
      }, { passive: true });
    });
  }

  function showMessage(title, detail, link) {
    target.innerHTML = `<div class="empty-state"><h3>${escapeHtml(title)}</h3><p>${escapeHtml(detail)}</p>` +
      (link ? `<p><a href="${escapeHtml(link.href)}" style="text-decoration:underline">${escapeHtml(link.text)}</a></p>` : "") + "</div>";
  }

  async function loadPage(page) {
    const requestId = ++state.requestId;
    try {
      const response = await trayApi.get(`/orders?page=${page}&per_page=${PER_PAGE}`);
      if (requestId !== state.requestId) return;
      const { orders = [], pagination = {} } = response.data || {};
      state.orders = page === 1 ? orders : state.orders.concat(orders);
      state.page = page;
      state.hasNext = Boolean(pagination.has_next);
      renderAll();
    } catch (error) {
      if (requestId !== state.requestId) return;
      if (error.status === 401) {
        showMessage("Log in to see your orders", "Your orders are kept on your account, not on this device.", { href: "./login.html", text: "Log in" });
      } else {
        showMessage("Orders unavailable", "We couldn't load your orders. Please try again in a moment.");
      }
    }
  }

  async function loadMenuImages() {
    // Photos come from the live menu, since orders only store item names and prices.
    try {
      const response = await trayApi.get("/menu");
      state.imageById = new Map((response.items || []).map((item) => [item.id, item.image_url || ""]));
      if (state.orders.length) renderAll();
    } catch (_) {}
  }

  async function reorder(orderNumber) {
    const order = ordersById.get(String(orderNumber));
    if (!order) return;
    let menu;
    try {
      menu = (await trayApi.get("/menu")).items || [];
    } catch (_) {
      trayNotify("Could not load the menu. Please try again.");
      return;
    }
    // Only items on the current menu can be added. Anything removed or sold out is reported.
    const current = new Map(menu.map((item) => [item.id, item]));
    const cart = trayStorage.get("trayup-cart", []);
    const unavailable = [];
    let added = 0;
    (order.items || []).forEach((entry) => {
      const item = current.get(entry.menu_item_id);
      if (!item) { unavailable.push(entry.item_name); return; }
      const quantity = Math.max(1, Number(entry.quantity) || 1);
      const existing = cart.find((line) => line.id === item.id);
      if (existing) existing.qty += quantity;
      else cart.push({ id: item.id, name: item.name, price: item.price_paise / 100, image: item.image_url || "", qty: quantity });
      added += quantity;
    });
    if (!added) {
      trayNotify("None of these items are available right now.");
      return;
    }
    trayStorage.set("trayup-cart", cart);
    if (unavailable.length) {
      trayNotify(`Added to your cart. No longer available: ${unavailable.join(", ")}`);
      return;
    }
    window.location.href = "./cart.html";
  }

  target.addEventListener("click", (event) => {
    const previous = event.target.closest("[data-carousel-prev]");
    const next = event.target.closest("[data-carousel-next]");
    if (previous || next) {
      const track = (previous || next).closest(".order-food-carousel").querySelector(".order-food-track");
      track.scrollLeft += (next ? 1 : -1) * track.clientWidth;
      const current = track.closest(".order-food-carousel").querySelector("[data-carousel-current]");
      if (current) current.textContent = String(Math.round(track.scrollLeft / track.clientWidth) + 1);
      return;
    }

    if (event.target.closest("#load-more")) {
      loadPage(state.page + 1);
      return;
    }

    const view = event.target.closest("[data-view]");
    if (view) {
      const details = view.closest("[data-order]").querySelector(".order-details");
      details.hidden = !details.hidden;
      view.textContent = details.hidden ? "View Details" : "Hide Details";
      return;
    }

    const reorderButton = event.target.closest("[data-reorder]");
    if (reorderButton) reorder(reorderButton.dataset.reorder);
  });

  // Earlier versions kept copies of orders in this browser, for whoever used it last. Remove them
  // so they can't show up for another student on a shared device. Orders now come from the server.
  trayStorage.remove("trayup-user-orders");
  trayStorage.remove("trayup-last-order");

  loadPage(1);
  loadMenuImages();
})();
