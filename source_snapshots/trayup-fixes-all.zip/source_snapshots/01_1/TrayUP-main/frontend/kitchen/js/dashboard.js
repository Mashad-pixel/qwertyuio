(function () {
  const demoMode = new URLSearchParams(window.location.search).get("demo") === "1";
  // The kitchen queue API only returns orders that still need kitchen work. Collected orders
  // are not in it, so there is no Collected column.
  const statuses = ["received", "preparing", "ready"];
  const labels = { received: "New", preparing: "Preparing", ready: "Ready" };
  const demoQueue = {
    received: [
      { id: 101, order_number: "TUP-4821", created_at: "10:24 AM", items: [{ item_name: "Masala Dosa", quantity: 2 }, { item_name: "Cold Coffee", quantity: 1 }] },
      { id: 102, order_number: "TUP-4825", created_at: "10:31 AM", items: [{ item_name: "Grilled Chicken Bowl", quantity: 1 }] }
    ],
    preparing: [{ id: 103, order_number: "TUP-4818", created_at: "10:11 AM", items: [{ item_name: "Paneer Butter Masala", quantity: 2 }] }],
    ready: [{ id: 104, order_number: "TUP-4809", created_at: "9:58 AM", items: [{ item_name: "Cheese Chilli Sandwich", quantity: 2 }, { item_name: "Mango Shake", quantity: 2 }] }]
  };

  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const column = (status) => document.querySelector('[data-status="' + status + '"]');

  // Accepts the API's ISO timestamps and the demo's plain text times.
  function placedAt(value) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
  }

  function updateTime() {
    document.getElementById("live-time").textContent = new Date().toLocaleString("en-IN", {
      weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit"
    });
  }
  updateTime();
  const clock = setInterval(updateTime, 30000);
  window.addEventListener("pagehide", () => clearInterval(clock));

  function showError(detail) {
    document.getElementById("summary").textContent = detail;
    statuses.forEach(status => {
      const col = column(status);
      const heading = col.querySelector("h2");
      col.textContent = ""; col.appendChild(heading);
      const p = document.createElement("p");
      p.className = "empty-state"; p.textContent = detail; col.appendChild(p);
    });
  }

  function actionFor(status, readOnly) {
    if (readOnly) return "";
    if (status === "received") return '<button class="btn btn-primary" data-next="preparing" type="button">Start preparing</button>';
    if (status === "preparing") return '<button class="btn btn-primary" data-next="ready" type="button">Mark ready</button>';
    // Collection is confirmed by scanning the student's code, never by a status change.
    return '<a class="btn btn-secondary" href="./scanner.html">Scan code to collect</a>';
  }

  function render(queue, readOnly) {
    const counts = statuses.map(s => Array.isArray(queue[s]) ? queue[s].length : 0);
    document.getElementById("summary").innerHTML =
      (readOnly ? '<div class="metric"><span>Mode</span><strong>Demo · read only</strong></div>' : "") +
      statuses.map((s, i) => '<div class="metric"><span>' + labels[s] + '</span><strong>' + counts[i] + "</strong></div>").join("");

    statuses.forEach(status => {
      const col = column(status);
      const heading = col.querySelector("h2").outerHTML;
      const orders = Array.isArray(queue[status]) ? queue[status] : [];
      const cards = orders.map(order => {
        const id = Number(order.id);
        const safeId = Number.isInteger(id) && id > 0 ? String(id) : "";
        const items = (order.items || []).map(item =>
          "<li><span>" + Math.max(1, Number(item.quantity) || 1) + " × " +
          esc(item.item_name || item.name || "Item") + "</span></li>"
        ).join("");
        return '<article class="order-ticket" data-order="' + safeId + '"><header><span>' +
          esc(order.order_number || "Order") + "</span><span>" + esc(placedAt(order.created_at)) +
          "</span></header><ul>" + items + "</ul>" + actionFor(status, readOnly) + "</article>";
      }).join("");
      col.innerHTML = heading + (cards || '<div class="empty-state" style="background:transparent">No orders</div>');
    });
  }

  async function load() {
    if (demoMode) return render(demoQueue, true);
    try {
      const response = await trayApi.get("/kitchen/orders");
      render(response?.data?.queue || {}, false);
    } catch (error) {
      showError(error.status === 401 ? "Please sign in with a kitchen account." :
        error.status === 403 ? "This account does not have kitchen access." :
        "Unable to load live orders. Retry when the backend is available.");
    }
  }

  document.getElementById("kitchen-board").addEventListener("click", async event => {
    const button = event.target.closest("[data-next]");
    if (!button || demoMode) return;
    const ticket = button.closest("[data-order]");
    if (!ticket || !ticket.dataset.order) return;
    button.disabled = true;
    try {
      await trayApi.patch("/kitchen/orders/" + ticket.dataset.order + "/status", { status: button.dataset.next });
      trayNotify("Order status updated.");
      await load();
    } catch (error) {
      button.disabled = false;
      trayNotify(error.message || "Could not update order status.");
    }
  });

  document.getElementById("logout").addEventListener("click", async () => {
    try { await trayAuth.logout(); } catch (_) {}
    window.location.href = "./login.html";
  });

  load();
  if (!demoMode) {
    const poll = setInterval(load, 15000);
    window.addEventListener("pagehide", () => clearInterval(poll));
  }
})();
