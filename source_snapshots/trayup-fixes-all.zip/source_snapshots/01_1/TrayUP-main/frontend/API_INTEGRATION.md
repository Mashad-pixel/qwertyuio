# Frontend API integration

| Endpoint | Method | Purpose | Authentication |
|---|---|---|---|
| `/api/auth/login` | POST | Staff or student login | None |
| `/api/auth/logout` | POST | End the current session | Session |
| `/api/auth/me` | GET | Current authenticated user | Session |
| `/api/orders` | POST | Create an order | Student login |
| `/api/orders` | GET | List the student's orders | Student login |
| `/api/orders/:id/tracking` | GET | Retrieve order tracking | Student login |
| `/api/payments/create-order` | POST | Create a Razorpay order | Session |
| `/api/payments/verify` | POST | Verify payment after checkout | Session |
| `/api/kitchen/orders` | GET | Retrieve the kitchen queue | Kitchen or admin |
| `/api/kitchen/orders/:id/status` | PATCH | Change an order status | Kitchen or admin |
| `/api/kitchen/collection/verify` | POST | Verify a collection token | Kitchen or admin |
| `/api/kitchen/collection/confirm` | POST | Confirm collection handover | Kitchen or admin |
| `/api/admin/orders` | GET | List orders, 20 per page. Query: `page`, `per_page` (max 50), `q` (order number, student name or email), `order_status`, `payment_status` | Admin |
| `/api/admin/orders/:id/cancel` | POST | Cancel an order (`reason` optional) | Admin |
| `/api/admin/menu` | GET | List all menu items, including unavailable ones | Admin |
| `/api/admin/menu` | POST | Create a menu item. Prices are whole paise (₹1 = 100) | Admin |
| `/api/admin/menu/:id` | PATCH | Update a menu item (any of `name`, `category`, `price_paise`, `is_available`, `stock_quantity`, `description`, `image_url`) | Admin |
| `/api/admin/staff` | GET | List ADMIN and KITCHEN accounts. Students are never listed here | Admin |
| `/api/admin/staff` | POST | Create a staff account (`name`, `email`, `role` ADMIN or KITCHEN, `password`) | Admin |
| `/api/admin/staff/:id` | PATCH | Change `role`, `is_active` or `password` for a staff account. An admin cannot demote or deactivate themselves | Admin |

Menu items cannot be deleted through the API. Disable an item with `is_available: false` instead, which hides it from students and keeps order history intact.

Self-service password reset is not implemented. Staff passwords can be reset by an admin through `PATCH /api/admin/staff/:id`. Students who forget their password have no reset route yet, so they cannot recover the account online.
