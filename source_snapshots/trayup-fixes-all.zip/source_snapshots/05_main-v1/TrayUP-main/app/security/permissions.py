from functools import wraps

from flask_login import current_user

from app.responses import error_response


def roles_required(*allowed_roles):
    """Allow the request only if the logged-in user has one of the given roles.

    Anonymous requests get a 401 even if the route forgot @login_required. Without this
    check, AnonymousUserMixin has no `role` attribute and the request would fail with a 500.
    Still, place @login_required above this decorator so the intent is explicit.
    """
    if not allowed_roles:
        raise ValueError("roles_required needs at least one role.")

    def decorator(view_func):
        @wraps(view_func)
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated:
                return error_response("AUTH_REQUIRED", "Please log in first.", 401)
            if getattr(current_user, "role", None) not in allowed_roles:
                return error_response(
                    "FORBIDDEN",
                    "You do not have permission to do this.",
                    403,
                )
            return view_func(*args, **kwargs)

        return wrapper

    return decorator
