from datetime import datetime, timezone

from app.extensions import db

DEFAULT_CANTEEN_NAME = "TrayUP Canteen"


def utcnow():
    return datetime.now(timezone.utc)


class CanteenSettings(db.Model):
    """Singleton settings row: the canteen's name, operating hours, and whether it takes orders.

    opens_at and closes_at are "HH:MM" strings in canteen-local time, or NULL when no hours are set.
    Strings keep the times exactly as the admin entered them, without any timezone conversion.
    """

    __tablename__ = "canteen_settings"
    __table_args__ = (
        db.CheckConstraint("id = 1", name="ck_canteen_settings_singleton"),
    )

    id = db.Column(db.Integer, primary_key=True, autoincrement=False)
    is_accepting_orders = db.Column(db.Boolean, nullable=False, default=True, server_default=db.true())
    closed_message = db.Column(db.String(200), nullable=True)
    canteen_name = db.Column(
        db.String(80),
        nullable=False,
        default=DEFAULT_CANTEEN_NAME,
        server_default=DEFAULT_CANTEEN_NAME,
    )
    opens_at = db.Column(db.String(5), nullable=True)
    closes_at = db.Column(db.String(5), nullable=True)
    updated_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        default=utcnow,
        onupdate=utcnow,
    )
