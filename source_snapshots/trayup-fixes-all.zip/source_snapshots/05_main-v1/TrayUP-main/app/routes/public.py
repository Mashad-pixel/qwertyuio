from flask import Blueprint, jsonify, request
from flask_wtf.csrf import generate_csrf
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from app.extensions import db
from app.responses import error_response
from app.services.canteen_service import get_status
from app.services.errors import OrderError
from app.services.menu_service import list_public_menu_items, serialize_public_menu_item
from app.services.report_service import date_bounds, popular_items

public_bp = Blueprint("public", __name__, url_prefix="/api")

# How many canteen-local days each popularity period covers, ending today.
POPULAR_PERIOD_DAYS = {"day": 1, "week": 7, "month": 30}
POPULAR_LIMIT = 50


@public_bp.get("/health")
def health():
    try:
        db.session.execute(text("SELECT 1"))
    except SQLAlchemyError:
        db.session.rollback()
        return jsonify(status="error", database="unavailable"), 503
    return jsonify(status="ok", database="ok"), 200


@public_bp.get("/csrf-token")
def csrf_token():
    response = jsonify(csrf_token=generate_csrf())
    response.headers["Cache-Control"] = "no-store"
    return response, 200


@public_bp.get("/menu")
def menu():
    items = list_public_menu_items()
    return jsonify(items=[serialize_public_menu_item(item) for item in items]), 200


@public_bp.get("/menu/popular")
def menu_popular():
    """Paid orders per menu item over today, this week or this month (canteen-local days).

    Only counts; no student or revenue data is exposed. Items removed from the menu have a null
    menu_item_id and are left out, because the student app cannot link them to a dish.
    """
    period = request.args.get("period", "day")
    days = POPULAR_PERIOD_DAYS.get(period)
    if days is None:
        return error_response("INVALID_PERIOD", "period must be day, week or month.", 400)

    try:
        start, end = date_bounds({}, default_days=days)
    except OrderError as exc:
        return error_response(exc.code, exc.message, exc.status)

    rows = popular_items(start, end, POPULAR_LIMIT)
    items = [
        {"menu_item_id": row["menu_item_id"], "quantity": row["quantity"]}
        for row in rows
        if row["menu_item_id"] is not None
    ]
    return jsonify(period=period, items=items), 200


@public_bp.get("/canteen/status")
def canteen_status():
    return jsonify(get_status()), 200
