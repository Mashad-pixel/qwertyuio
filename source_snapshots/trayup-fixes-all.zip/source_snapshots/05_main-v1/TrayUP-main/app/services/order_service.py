import hashlib
import secrets
from datetime import timedelta

from flask import current_app
from sqlalchemy.exc import IntegrityError

from app.extensions import db
from app.models.order import Order, OrderStatus, PaymentStatus
from app.models.order_item import OrderItem
from app.models.order_status_history import OrderStatusHistory
from app.models.payment import Payment, PaymentRecordStatus
from app.services.collection_service import expire_collection_tokens
from app.services.canteen_service import is_accepting_orders
from app.services.errors import OrderError
from app.services.inventory_service import release_reservations, reserve_stock, return_sold_stock
from app.services.pricing_service import normalize_requested_items, price_order
from app.services.time_utils import as_utc, utcnow
from app.services.firebase_service import sync_order_to_firebase

MAX_IDEMPOTENCY_KEY_LENGTH = 64
EXPIRY_NOTE = "Payment not completed in time"


def _generate_order_number():
    stamp = utcnow().strftime("%y%m%d")
    return f"TU{stamp}{secrets.token_hex(4).upper()}"


def _hash_token(raw_token):
    # Only the hash is stored. The raw token is returned to the student once.
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()


def _validate_idempotency_key(key):
    if key is None:
        return None
    key = key.strip()
    if not key or len(key) > MAX_IDEMPOTENCY_KEY_LENGTH:
        raise OrderError(
            "INVALID_IDEMPOTENCY_KEY",
            f"Idempotency-Key must be 1 to {MAX_IDEMPOTENCY_KEY_LENGTH} characters.",
        )
    return key


def _find_existing_order(student_id, key):
    return Order.query.filter_by(student_id=student_id, idempotency_key=key).first()


def payment_window_closed(order, now=None):
    """True once an unpaid order has waited longer than ORDER_PAYMENT_EXPIRY_MINUTES."""
    now = now or utcnow()
    minutes = current_app.config["ORDER_PAYMENT_EXPIRY_MINUTES"]
    return as_utc(order.created_at) <= now - timedelta(minutes=minutes)


def expire_order(order, now=None):
    """Cancel one unpaid order and free its held stock. The caller must commit."""
    now = now or utcnow()
    previous_status = order.order_status

    order.order_status = OrderStatus.CANCELLED
    order.payment_status = PaymentStatus.FAILED
    release_reservations(order.id)

    db.session.add(OrderStatusHistory(
        order_id=order.id,
        previous_status=previous_status,
        new_status=OrderStatus.CANCELLED,
        changed_by=None,  # System change, not a staff member
        changed_at=now,
        notes=EXPIRY_NOTE,
    ))


def _expiry_cutoff(now):
    """Unpaid orders created at or before this instant have used up their payment window."""
    minutes = current_app.config["ORDER_PAYMENT_EXPIRY_MINUTES"]
    return now - timedelta(minutes=minutes)


def _overdue_unpaid_query(cutoff):
    return Order.query.filter(
        Order.order_status == OrderStatus.PENDING_PAYMENT,
        Order.payment_status == PaymentStatus.PENDING,
        Order.created_at <= cutoff,
    )


def expire_unpaid_orders(batch_size=None, now=None):
    """Cancel unpaid orders whose payment window has closed. Returns how many were expired.

    Work is done in batches, and each batch is committed on its own. A large backlog therefore
    never holds locks for long, and a failure only rolls back the batch that was in progress.
    Paid orders are never touched.

    On Postgres, rows locked by another transaction (for example a payment webhook confirming
    an order right now) are skipped. That transaction handles the order itself, or the next
    sweep picks it up. The scheduled job never waits behind a payment.

    Runs lazily before each new order, and from the `expire-orders` CLI command.
    """
    now = now or utcnow()
    batch_size = batch_size or current_app.config["ORDER_EXPIRY_BATCH_SIZE"]
    cutoff = _expiry_cutoff(now)

    expired_total = 0
    while True:
        try:
            batch = (
                _overdue_unpaid_query(cutoff)
                .order_by(Order.created_at.asc(), Order.id.asc())
                .with_for_update(skip_locked=True)
                .limit(batch_size)
                .all()
            )
            if not batch:
                db.session.commit()
                break

            for order in batch:
                expire_order(order, now)
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise

        # Every order in the batch has left the candidate set, so each pass makes progress.
        expired_total += len(batch)

    if expired_total:
        current_app.logger.info(
            "Expired %d unpaid order(s) whose payment window had closed.",
            expired_total,
        )
    return expired_total


def expiry_status(now=None):
    """Read-only check for the expiry job. Changes nothing.

    `overdue_orders` counts unpaid orders past their payment window. `oldest_overdue_minutes` is
    how long the oldest of them has been waiting to be expired. `stalled` is True when that wait
    exceeds ORDER_EXPIRY_ALERT_MINUTES, which means the scheduled sweep is not running.
    """
    now = now or utcnow()
    window = current_app.config["ORDER_PAYMENT_EXPIRY_MINUTES"]
    alert_after = current_app.config["ORDER_EXPIRY_ALERT_MINUTES"]

    overdue = _overdue_unpaid_query(_expiry_cutoff(now))
    overdue_count = overdue.count()

    oldest_overdue_minutes = None
    if overdue_count:
        oldest = overdue.order_by(Order.created_at.asc(), Order.id.asc()).first()
        overdue_since = as_utc(oldest.created_at) + timedelta(minutes=window)
        oldest_overdue_minutes = round((now - overdue_since).total_seconds() / 60, 1)

    return {
        "payment_window_minutes": window,
        "alert_after_minutes": alert_after,
        "overdue_orders": overdue_count,
        "oldest_overdue_minutes": oldest_overdue_minutes,
        "stalled": oldest_overdue_minutes is not None and oldest_overdue_minutes > alert_after,
    }


def _sweep_expired_orders_safely():
    """Free stock held by expired orders before a new order is priced.

    If the sweep fails, students can still order. Their order may just see less
    free stock until the next sweep. The failure is logged.
    """
    try:
        expire_unpaid_orders()
    except Exception:
        current_app.logger.exception("Could not expire unpaid orders before creating a new order.")


def create_order(student_id, raw_items, idempotency_key=None):
    """Create a pending_payment order and reserve its stock in one transaction.

    Returns (order, raw_tracking_token). raw_tracking_token is None when an existing
    order is returned for a retried key, because the raw token was shown the first time.
    """
    key = _validate_idempotency_key(idempotency_key)

    if key:
        existing = _find_existing_order(student_id, key)
        if existing:
            return existing, None

    requested = normalize_requested_items(raw_items)

    if not is_accepting_orders():
        raise OrderError(
            "CANTEEN_CLOSED",
            "The canteen is not accepting new orders right now.",
            409,
        )

    _sweep_expired_orders_safely()

    priced = price_order(requested)
    raw_token = secrets.token_urlsafe(32)

    order = Order(
        order_number=_generate_order_number(),
        student_id=student_id,
        idempotency_key=key,
        subtotal_paise=priced.subtotal_paise,
        discount_paise=priced.discount_paise,
        tax_paise=priced.tax_paise,
        total_paise=priced.total_paise,
        payment_status=PaymentStatus.PENDING,
        order_status=OrderStatus.PENDING_PAYMENT,
        tracking_token_hash=_hash_token(raw_token),
    )

    for line in priced.lines:
        order.items.append(
            OrderItem(
                menu_item_id=line.menu_item_id,
                item_name_snapshot=line.item_name,
                unit_price_snapshot_paise=line.unit_price_paise,
                quantity=line.quantity,
                line_total_paise=line.line_total_paise,
            )
        )

    try:
        db.session.add(order)
        db.session.flush()  # Assigns order.id, which the stock reservations need.
        reserve_stock(order.id, priced.lines)
        db.session.commit()
    except IntegrityError:
        # A parallel request with the same key may have won the race.
        db.session.rollback()
        if key:
            existing = _find_existing_order(student_id, key)
            if existing:
                return existing, None
        raise OrderError(
            "ORDER_CREATE_FAILED",
            "Could not create the order. Please try again.",
            500,
        )
    except Exception:
        # Also covers OrderError from reserve_stock. The order and any partial holds are rolled back.
        db.session.rollback()
        raise

    committed_order = db.session.get(Order, order.id)
    if committed_order is not None:
        sync_order_to_firebase(committed_order)
    return committed_order or order, raw_token


def cancel_order(order_id, staff_user_id, reason):
    """Admin cancels an order. Returns (order, refund_required).

    Unpaid orders free their held stock. Paid orders get their sold stock back, and
    their money is flagged REFUND_REQUIRED until an admin refunds it. In both cases
    the collection code stops working immediately.
    """
    try:
        order = Order.query.filter_by(id=order_id).with_for_update().first()
        if order is None:
            raise OrderError("ORDER_NOT_FOUND", "Order not found.", 404)

        if order.order_status == OrderStatus.COLLECTED:
            raise OrderError(
                "ORDER_ALREADY_COLLECTED",
                "This order has already been collected and cannot be cancelled.",
                409,
            )
        if order.order_status == OrderStatus.CANCELLED:
            raise OrderError("ALREADY_CANCELLED", "This order is already cancelled.", 409)

        now = utcnow()
        previous_status = order.order_status

        release_reservations(order.id)
        return_sold_stock(order.id)
        expire_collection_tokens(order.id, now)

        captured_payments = Payment.query.filter(
            Payment.order_id == order.id,
            Payment.status.in_([PaymentRecordStatus.PAID, PaymentRecordStatus.PARTIALLY_REFUNDED]),
        ).all()
        for payment in captured_payments:
            payment.status = PaymentRecordStatus.REFUND_REQUIRED
        refund_required = bool(captured_payments)

        # Paid and partly refunded orders keep their payment status. Only unpaid orders change.
        if order.payment_status == PaymentStatus.PENDING:
            order.payment_status = PaymentStatus.FAILED

        order.order_status = OrderStatus.CANCELLED
        db.session.add(OrderStatusHistory(
            order_id=order.id,
            previous_status=previous_status,
            new_status=OrderStatus.CANCELLED,
            changed_by=staff_user_id,
            changed_at=now,
            notes=reason,
        ))

        db.session.commit()
        committed_order = db.session.get(Order, order.id)
        if committed_order is not None:
            sync_order_to_firebase(committed_order)
        return committed_order or order, refund_required

    except Exception:
        db.session.rollback()
        raise
