import re

from app.extensions import db
from app.models.canteen import DEFAULT_CANTEEN_NAME, CanteenSettings
from app.services.errors import ServiceValidationError

SINGLETON_ID = 1
CANTEEN_NAME_MAX_LENGTH = 80
CLOSED_MESSAGE_MAX_LENGTH = 200
# 24-hour "HH:MM", for example 08:30 or 18:00.
TIME_PATTERN = re.compile(r"([01]\d|2[0-3]):[0-5]\d")
ALLOWED_FIELDS = frozenset({"is_accepting_orders", "closed_message"})
SETTINGS_FIELDS = frozenset({
    "name", "opens_at", "closes_at", "is_accepting_orders", "closed_message",
})


def _current():
    return db.session.get(CanteenSettings, SINGLETON_ID)


def get_status():
    """Public view. The canteen is open unless an admin has explicitly closed it."""
    settings = _current()
    name = (settings.canteen_name if settings else None) or DEFAULT_CANTEEN_NAME
    opens_at = settings.opens_at if settings else None
    closes_at = settings.closes_at if settings else None
    if settings is None or settings.is_accepting_orders:
        return {
            "is_accepting_orders": True,
            "message": None,
            "name": name,
            "opens_at": opens_at,
            "closes_at": closes_at,
        }
    return {
        "is_accepting_orders": False,
        "message": settings.closed_message,
        "name": name,
        "opens_at": opens_at,
        "closes_at": closes_at,
    }


def admin_settings():
    """Everything the admin settings page edits."""
    settings = _current()
    return {
        "name": (settings.canteen_name if settings else None) or DEFAULT_CANTEEN_NAME,
        "opens_at": settings.opens_at if settings else None,
        "closes_at": settings.closes_at if settings else None,
        "is_accepting_orders": settings.is_accepting_orders if settings else True,
        "closed_message": settings.closed_message if settings else None,
    }


def is_accepting_orders():
    return get_status()["is_accepting_orders"]


def update_status(data):
    """Open or close the canteen (kept for the original status endpoint)."""
    errors = {}
    unknown = sorted(set(data) - ALLOWED_FIELDS)
    if unknown:
        errors["unknown_fields"] = f"Unsupported fields: {', '.join(unknown)}."

    if "is_accepting_orders" not in data:
        errors["is_accepting_orders"] = "This field is required."
    elif not isinstance(data["is_accepting_orders"], bool):
        errors["is_accepting_orders"] = "Must be true or false."

    message = data.get("closed_message")
    if message is not None and not isinstance(message, str):
        errors["closed_message"] = "Must be a string."
    elif isinstance(message, str) and len(message.strip()) > CLOSED_MESSAGE_MAX_LENGTH:
        errors["closed_message"] = f"Must be at most {CLOSED_MESSAGE_MAX_LENGTH} characters."

    if errors:
        raise ServiceValidationError(errors, "Canteen status update is invalid.")

    is_open = data["is_accepting_orders"]
    cleaned_message = message.strip() if isinstance(message, str) and message.strip() else None

    settings = _current()
    if settings is None:
        settings = CanteenSettings(id=SINGLETON_ID)
        db.session.add(settings)
    settings.is_accepting_orders = is_open
    settings.closed_message = None if is_open else cleaned_message
    db.session.commit()
    return get_status()


def _clean_name(value, errors):
    if not isinstance(value, str):
        errors["name"] = "Must be a string."
        return None
    value = value.strip()
    if not value:
        errors["name"] = "Cannot be empty."
        return None
    if len(value) > CANTEEN_NAME_MAX_LENGTH:
        errors["name"] = f"Must be at most {CANTEEN_NAME_MAX_LENGTH} characters."
        return None
    return value


def _clean_time(field, value, errors):
    """Return the time as "HH:MM", or None to clear it. Invalid input is recorded in errors."""
    if value is None or value == "":
        return None
    if not isinstance(value, str) or not TIME_PATTERN.fullmatch(value):
        errors[field] = "Use 24-hour HH:MM, for example 08:30."
        return None
    return value


def update_settings(data):
    """Update any of the settings fields. Fields left out of the request keep their current value.

    Opening and closing times are set together or cleared together. Closing time must come after
    opening time on the same day; hours that run past midnight are not supported.
    """
    errors = {}
    unknown = sorted(set(data) - SETTINGS_FIELDS)
    if unknown:
        errors["unknown_fields"] = f"Unsupported fields: {', '.join(unknown)}."

    changes = {}
    if "name" in data:
        name = _clean_name(data["name"], errors)
        if name is not None:
            changes["canteen_name"] = name
    if "opens_at" in data:
        changes["opens_at"] = _clean_time("opens_at", data["opens_at"], errors)
    if "closes_at" in data:
        changes["closes_at"] = _clean_time("closes_at", data["closes_at"], errors)
    if "is_accepting_orders" in data:
        if isinstance(data["is_accepting_orders"], bool):
            changes["is_accepting_orders"] = data["is_accepting_orders"]
        else:
            errors["is_accepting_orders"] = "Must be true or false."
    if "closed_message" in data:
        message = data["closed_message"]
        if message is None or (isinstance(message, str) and not message.strip()):
            changes["closed_message"] = None
        elif not isinstance(message, str):
            errors["closed_message"] = "Must be a string."
        elif len(message.strip()) > CLOSED_MESSAGE_MAX_LENGTH:
            errors["closed_message"] = f"Must be at most {CLOSED_MESSAGE_MAX_LENGTH} characters."
        else:
            changes["closed_message"] = message.strip()

    if errors:
        raise ServiceValidationError(errors, "Canteen settings update is invalid.")

    current = _current()
    opens = changes["opens_at"] if "opens_at" in changes else (current.opens_at if current else None)
    closes = changes["closes_at"] if "closes_at" in changes else (current.closes_at if current else None)
    if (opens is None) != (closes is None):
        hours_error = "Set both opening and closing times, or clear both."
        raise ServiceValidationError({"opens_at": hours_error, "closes_at": hours_error})
    if opens is not None and closes <= opens:
        raise ServiceValidationError({"closes_at": "Closing time must be after opening time."})

    settings = current or CanteenSettings(id=SINGLETON_ID)
    if current is None:
        db.session.add(settings)
    for field in ("canteen_name", "opens_at", "closes_at", "is_accepting_orders"):
        if field in changes:
            setattr(settings, field, changes[field])
    # A closed message only makes sense while closed. Opening the canteen clears it.
    if settings.is_accepting_orders:
        settings.closed_message = None
    elif "closed_message" in changes:
        settings.closed_message = changes["closed_message"]
    db.session.commit()
    return admin_settings()
