// The menu comes from the database through GET /api/menu. Nothing about a dish is hard-coded here.
//
// The cart lives in the browser, so it can hold dishes that have since been renamed, removed or
// re-numbered. Checkout sends each cart line's menu_item_id, and the server charges whatever dish
// has that id. So every page that uses the cart first reconciles it against the live menu. A line
// is kept only when both its id AND its name still match a live dish.
(function (root) {
  const MAX_QUANTITY_PER_ITEM = 20; // Must match MAX_QUANTITY_PER_ITEM in app/services/pricing_service.py
  const PLACEHOLDER_IMAGE = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='450'%3E%3Crect width='100%25' height='100%25' fill='%23e8e2d2'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' dominant-baseline='middle' fill='%23746b5b' font-family='sans-serif' font-size='28'%3ENo photo yet%3C/text%3E%3C/svg%3E";
  const CART_KEY = "trayup-cart";

  // Maps a dish from GET /api/menu to the shape the student pages use. Prices are stored in paise.
  function toProduct(item) {
    return {
      id: Number(item.id),
      name: String(item.name || ""),
      category: String(item.category || ""),
      description: String(item.description || ""),
      price: Number(item.price_paise) / 100,
      image: item.image_url || PLACEHOLDER_IMAGE,
      isAvailable: true // The public menu only lists dishes that can be ordered right now.
    };
  }

  function normaliseName(value) {
    return String(value ?? "").trim().toLowerCase();
  }

  // Pure function (no browser APIs) so it can be tested directly.
  // Returns the cart as it should be now, plus the names of dropped and capped lines.
  function reconcileCart(cart, liveProducts) {
    const byId = new Map(liveProducts.map((product) => [product.id, product]));
    const kept = [];
    const removed = [];
    const capped = [];

    (Array.isArray(cart) ? cart : []).forEach((line) => {
      const live = byId.get(Number(line.id));
      const quantity = Math.floor(Number(line.qty));
      if (!live || normaliseName(live.name) !== normaliseName(line.name) || !(quantity > 0)) {
        removed.push(String(line.name || "An item"));
        return;
      }

      const existing = kept.find((entry) => entry.id === live.id);
      const requested = (existing ? existing.qty : 0) + quantity;
      const allowed = Math.min(requested, MAX_QUANTITY_PER_ITEM);
      if (requested > MAX_QUANTITY_PER_ITEM && !capped.includes(live.name)) capped.push(live.name);

      if (existing) existing.qty = allowed;
      else kept.push({ ...live, qty: allowed });
    });

    return { cart: kept, removed, capped };
  }

  let productsPromise = null;
  function products() {
    if (!productsPromise) {
      productsPromise = root.trayApi.get("/menu")
        .then((data) => (Array.isArray(data?.items) ? data.items.map(toProduct) : []))
        .catch((error) => {
          productsPromise = null; // Allow a retry on the next call.
          throw error;
        });
    }
    return productsPromise;
  }

  const popularCache = new Map();
  // Resolves to Map(menu item id -> paid units) for "day", "week" or "month".
  function popular(period) {
    if (!popularCache.has(period)) {
      const request = root.trayApi.get(`/menu/popular?period=${encodeURIComponent(period)}`)
        .then((data) => new Map((data?.items || []).map((row) => [Number(row.menu_item_id), Number(row.quantity)])))
        .catch((error) => {
          popularCache.delete(period);
          throw error;
        });
      popularCache.set(period, request);
    }
    return popularCache.get(period);
  }

  // Brings the stored cart in line with the live menu, saves it if it changed, and reports what
  // was removed. Rejects if the menu cannot be loaded. Callers must not treat the cart as valid then.
  function refreshCart() {
    return products().then((live) => {
      const stored = root.trayStorage.get(CART_KEY, []);
      const result = reconcileCart(stored, live);
      if (JSON.stringify(result.cart) !== JSON.stringify(stored)) {
        root.trayStorage.set(CART_KEY, result.cart);
      }
      if (result.removed.length && root.trayNotify) {
        root.trayNotify(`No longer on the menu, removed from your cart: ${result.removed.join(", ")}`);
      }
      if (result.capped.length && root.trayNotify) {
        root.trayNotify(`Quantity limited to ${MAX_QUANTITY_PER_ITEM} per dish: ${result.capped.join(", ")}`);
      }
      return result.cart;
    });
  }

  const api = {
    MAX_QUANTITY_PER_ITEM,
    PLACEHOLDER_IMAGE,
    toProduct,
    reconcileCart,
    products,
    popular,
    refreshCart,
    // Forget cached menu data, e.g. after the user comes back to the page.
    refresh() {
      productsPromise = null;
      popularCache.clear();
    }
  };

  root.trayCatalog = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
