(function () {
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);

  const content = document.querySelector(".admin-content");
  content.innerHTML = `<h1 class="admin-title">Canteen settings</h1>
    <form id="settings-form" class="card" style="max-width:620px;margin-top:22px;padding:22px">
      <div class="field"><label for="canteen-name">Canteen name</label><input id="canteen-name" maxlength="80" required></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div class="field"><label for="open-time">Opening time</label><input id="open-time" type="time"></div>
        <div class="field"><label for="close-time">Closing time</label><input id="close-time" type="time"></div>
      </div>
      <p style="color:var(--muted);font-size:12px;margin:-4px 0 12px">Leave both times empty if the canteen has no set hours. Times are canteen local time.</p>
      <div class="field"><label for="operating-status">Operating status</label>
        <select id="operating-status"><option value="open">Open</option><option value="closed">Closed</option></select>
      </div>
      <div class="field"><label for="closed-message">Message shown to students when closed</label><input id="closed-message" maxlength="200"></div>
      <p id="settings-note" style="color:var(--muted);font-size:13px;min-height:1.2em;margin:0 0 12px"></p>
      <button class="btn btn-primary" type="submit">Save settings</button>
    </form>`;

  const form = document.getElementById("settings-form");
  const nameInput = document.getElementById("canteen-name");
  const opensInput = document.getElementById("open-time");
  const closesInput = document.getElementById("close-time");
  const statusInput = document.getElementById("operating-status");
  const messageInput = document.getElementById("closed-message");
  const note = document.getElementById("settings-note");

  function errorText(error) {
    const details = error?.data?.details;
    if (details && typeof details === "object") {
      const first = Object.values(details).find(Boolean);
      if (first) return String(first);
    }
    return error?.message || "Something went wrong. Please try again.";
  }

  function fill(settings) {
    nameInput.value = settings.name || "";
    opensInput.value = settings.opens_at || "";
    closesInput.value = settings.closes_at || "";
    statusInput.value = settings.is_accepting_orders ? "open" : "closed";
    messageInput.value = settings.closed_message || "";
  }

  async function load() {
    try {
      const data = await trayApi.get("/admin/canteen/settings");
      fill(data.settings);
      note.textContent = "";
    } catch (error) {
      note.textContent = errorText(error);
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = {
      name: nameInput.value.trim(),
      opens_at: opensInput.value || null,
      closes_at: closesInput.value || null,
      is_accepting_orders: statusInput.value === "open",
      closed_message: messageInput.value.trim() || null
    };
    try {
      const data = await trayApi.patch("/admin/canteen/settings", payload);
      fill(data.settings);
      note.textContent = "Saved.";
      trayNotify("Canteen settings saved");
    } catch (error) {
      note.textContent = errorText(error);
      trayNotify(errorText(error));
    }
  });

  load();
})();
