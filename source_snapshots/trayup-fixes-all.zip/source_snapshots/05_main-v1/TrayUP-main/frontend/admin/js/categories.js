(function () {
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);

  const content = document.querySelector(".admin-content");
  content.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center"><h1 class="admin-title">Categories</h1><button class="btn btn-primary" id="add-category" type="button">Add category</button></div><div class="card table-card" style="margin-top:22px"><table class="data-table"><thead><tr><th>Name</th><th>Menu items</th><th>Actions</th></tr></thead><tbody id="category-body"><tr><td colspan="3">Loading categories…</td></tr></tbody></table></div>`;
  const body = document.getElementById("category-body");

  let categories = [];

  function errorText(error) {
    const details = error?.data?.details;
    if (details && typeof details === "object") {
      const first = Object.values(details).find(Boolean);
      if (first) return String(first);
    }
    return error?.message || "Something went wrong. Please try again.";
  }

  function findCategory(id) {
    return categories.find((entry) => entry.id === id);
  }

  function render() {
    if (!categories.length) {
      body.innerHTML = `<tr><td colspan="3">No categories yet. Add one before creating menu items.</td></tr>`;
      return;
    }
    body.innerHTML = categories.map((category) => `<tr>
      <td><strong>${esc(category.name)}</strong></td>
      <td>${Number(category.item_count)}</td>
      <td><button class="btn btn-secondary" data-rename="${Number(category.id)}" type="button">Rename</button> <button class="btn" data-delete="${Number(category.id)}" type="button" style="color:var(--danger)">Delete</button></td>
    </tr>`).join("");
  }

  async function load() {
    try {
      const data = await trayApi.get("/admin/categories");
      categories = data.categories;
      render();
    } catch (error) {
      body.innerHTML = `<tr><td colspan="3">${esc(errorText(error))}</td></tr>`;
    }
  }

  async function addCategory() {
    const name = prompt("Category name");
    if (name === null) return;
    try {
      await trayApi.post("/admin/categories", { name });
      trayNotify("Category added");
      await load();
    } catch (error) {
      trayNotify(errorText(error));
    }
  }

  async function renameCategory(id) {
    const category = findCategory(id);
    if (!category) return;
    const name = prompt("Category name", category.name);
    if (name === null) return;
    try {
      const data = await trayApi.patch(`/admin/categories/${id}`, { name });
      const moved = data.category.item_count;
      trayNotify(moved ? `Renamed. ${moved} menu item(s) moved to the new name.` : "Category renamed");
      await load();
    } catch (error) {
      trayNotify(errorText(error));
    }
  }

  async function deleteCategory(id) {
    const category = findCategory(id);
    if (!category) return;
    if (!confirm(`Delete the category "${category.name}"?`)) return;
    try {
      await trayApi.del(`/admin/categories/${id}`);
      trayNotify("Category deleted");
      await load();
    } catch (error) {
      trayNotify(errorText(error));
    }
  }

  content.addEventListener("click", (event) => {
    const add = event.target.closest("#add-category");
    const rename = event.target.closest("[data-rename]");
    const remove = event.target.closest("[data-delete]");
    if (add) addCategory();
    else if (rename) renameCategory(Number(rename.dataset.rename));
    else if (remove) deleteCategory(Number(remove.dataset.delete));
  });

  load();
})();
