from flask import Blueprint, request
from flask_login import current_user, login_required
from sqlalchemy.exc import IntegrityError

from app.extensions import db
from app.models.user import User, UserRole
from app.responses import error_response, success_response
from app.security.account_rules import (
    is_valid_email,
    is_valid_name,
    normalize_email,
    password_problem,
)
from app.security.permissions import roles_required

admin_staff_bp = Blueprint("admin_staff", __name__, url_prefix="/api/admin/staff")

# Students are managed through registration only. This API can never create, edit or
# disable a student account.
STAFF_ROLES = (UserRole.ADMIN, UserRole.KITCHEN)
UPDATABLE_FIELDS = frozenset({"role", "is_active", "password"})


def _json_object():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else None


def _serialize(user):
    return {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "role": user.role,
        "is_active": user.is_active,
        "created_at": user.created_at.isoformat() if user.created_at else None,
    }


def _staff_query():
    return User.query.filter(User.role.in_(STAFF_ROLES))


def _invalid_role_response():
    return error_response("INVALID_ROLE", "Role must be ADMIN or KITCHEN.", 400)


@admin_staff_bp.get("")
@login_required
@roles_required(UserRole.ADMIN)
def list_staff():
    users = _staff_query().order_by(User.name, User.id).all()
    return success_response("Staff retrieved", {"staff": [_serialize(u) for u in users]})


@admin_staff_bp.post("")
@login_required
@roles_required(UserRole.ADMIN)
def create_staff():
    payload = _json_object()
    if payload is None:
        return error_response("INVALID_JSON", "Request body must be a JSON object.", 400)

    name = payload.get("name")
    email = payload.get("email")
    password = payload.get("password")
    role = payload.get("role")

    if not all(isinstance(value, str) for value in (name, email, password, role)):
        return error_response(
            "INVALID_STAFF",
            "Name, email, role and password are required.",
            400,
        )

    name = name.strip()
    email = normalize_email(email)

    if not is_valid_name(name):
        return error_response("INVALID_STAFF", "Enter a name (up to 100 characters).", 400)
    if not is_valid_email(email):
        return error_response("INVALID_STAFF", "Enter a valid email address.", 400)
    if role not in STAFF_ROLES:
        return _invalid_role_response()

    problem = password_problem(password)
    if problem:
        return error_response("INVALID_STAFF", problem, 400)

    if User.query.filter_by(email=email).first() is not None:
        return error_response(
            "EMAIL_UNAVAILABLE",
            "An account with this email already exists.",
            409,
        )

    user = User(name=name, email=email, role=role, is_active=True)
    user.set_password(password)
    db.session.add(user)
    try:
        db.session.commit()
    except IntegrityError:
        # The unique email constraint handles two requests creating the same account at once.
        db.session.rollback()
        return error_response(
            "EMAIL_UNAVAILABLE",
            "An account with this email already exists.",
            409,
        )

    return success_response("Staff account created", _serialize(user), status=201)


@admin_staff_bp.patch("/<int:user_id>")
@login_required
@roles_required(UserRole.ADMIN)
def update_staff(user_id):
    user = _staff_query().filter(User.id == user_id).with_for_update().first()
    if user is None:
        return error_response("STAFF_NOT_FOUND", "Staff account not found.", 404)

    payload = _json_object()
    if payload is None:
        return error_response("INVALID_JSON", "Request body must be a JSON object.", 400)

    unknown = sorted(set(payload) - UPDATABLE_FIELDS)
    if unknown:
        return error_response(
            "INVALID_STAFF",
            f"Unsupported fields: {', '.join(unknown)}.",
            400,
        )
    if not payload:
        return error_response("INVALID_STAFF", "Provide a role, is_active or password to update.", 400)

    new_role = user.role
    if "role" in payload:
        if payload["role"] not in STAFF_ROLES:
            return _invalid_role_response()
        new_role = payload["role"]

    new_active = user.is_active
    if "is_active" in payload:
        if not isinstance(payload["is_active"], bool):
            return error_response("INVALID_STAFF", "'is_active' must be true or false.", 400)
        new_active = payload["is_active"]

    if "password" in payload:
        problem = password_problem(payload["password"])
        if problem:
            return error_response("INVALID_STAFF", problem, 400)

    # Stop an admin from locking themselves out. The caller is always an active admin, so
    # any other admin's access can be changed without leaving the system with no admin.
    removes_own_admin_access = user.id == current_user.id and (
        new_role != UserRole.ADMIN or not new_active
    )
    if removes_own_admin_access:
        return error_response(
            "SELF_LOCKOUT",
            "You cannot remove your own admin access.",
            409,
        )

    user.role = new_role
    user.is_active = new_active
    if "password" in payload:
        user.set_password(payload["password"])

    db.session.commit()
    return success_response("Staff account updated", _serialize(user))
