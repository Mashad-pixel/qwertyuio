from flask import Blueprint, request
from flask_login import current_user, login_required

from app.extensions import limiter
from app.models.recovery import AccountRecoveryRequest
from app.models.user import UserRole
from app.responses import error_response, success_response
from app.security.permissions import roles_required
from app.services.account_recovery import (
    RecoveryError,
    create_backup_codes,
    redeem_backup_code,
    request_code,
    reset_password,
    submit_support_request,
    verify_code,
)

recovery_bp = Blueprint("recovery", __name__, url_prefix="/api")

# The same reply whether or not the email matches an account.
CODE_SENT_MESSAGE = "If an account matches that email, we’ve sent a 6-digit code. It expires in 5 minutes."


def _json_object():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else None


def _invalid_json():
    return error_response("INVALID_JSON", "Request body must be a JSON object.", 400)


def _recovery_error(exc):
    return error_response(exc.code, exc.message, exc.status)


@recovery_bp.post("/forgot/start")
@limiter.limit("10 per hour")
def forgot_start():
    payload = _json_object()
    if payload is None:
        return _invalid_json()
    try:
        request_code(payload.get("identifier"))
    except RecoveryError as exc:
        return _recovery_error(exc)
    return success_response(CODE_SENT_MESSAGE, {})


@recovery_bp.post("/forgot/resend")
@limiter.limit("5 per 15 minutes")
def forgot_resend():
    payload = _json_object()
    if payload is None:
        return _invalid_json()
    try:
        request_code(payload.get("identifier"))
    except RecoveryError as exc:
        return _recovery_error(exc)
    return success_response(CODE_SENT_MESSAGE, {})


@recovery_bp.post("/forgot/verify")
@limiter.limit("20 per 15 minutes")
def forgot_verify():
    payload = _json_object()
    if payload is None:
        return _invalid_json()
    try:
        token = verify_code(payload.get("identifier"), payload.get("otp"))
    except RecoveryError as exc:
        return _recovery_error(exc)
    return success_response("Code accepted", {"resetToken": token})


@recovery_bp.post("/forgot/reset")
@limiter.limit("10 per 15 minutes")
def forgot_reset():
    payload = _json_object()
    if payload is None:
        return _invalid_json()
    try:
        reset_password(payload.get("resetToken"), payload.get("password"))
    except RecoveryError as exc:
        return _recovery_error(exc)
    return success_response("Password updated. Sign in with your new password.", {})


@recovery_bp.post("/recovery/code")
@limiter.limit("10 per hour")
def recovery_code():
    payload = _json_object()
    if payload is None:
        return _invalid_json()
    try:
        token = redeem_backup_code(payload.get("identifier"), payload.get("code"))
    except RecoveryError as exc:
        return _recovery_error(exc)
    return success_response("Recovery code accepted", {"resetToken": token})


@recovery_bp.post("/recovery/request")
@limiter.limit("5 per hour")
def recovery_request():
    payload = _json_object()
    if payload is None:
        return _invalid_json()
    try:
        ref = submit_support_request(payload)
    except RecoveryError as exc:
        return _recovery_error(exc)
    return success_response("Request received", {"ref": ref}, 201)


@recovery_bp.post("/auth/recovery-codes")
@login_required
@limiter.limit("5 per hour")
def generate_recovery_codes():
    # Replaces any unused codes. The codes are shown once; the server keeps only their hashes.
    codes = create_backup_codes(current_user)
    return success_response(
        "Save these codes somewhere safe. Each one works once, and they are not shown again.",
        {"codes": codes},
        201,
    )


@recovery_bp.get("/admin/recovery-requests")
@login_required
@roles_required(UserRole.ADMIN)
def list_recovery_requests():
    rows = (
        AccountRecoveryRequest.query.filter_by(status="pending")
        .order_by(AccountRecoveryRequest.created_at.desc())
        .limit(100)
        .all()
    )
    return success_response("Recovery requests", {
        "requests": [
            {
                "ref": row.ref,
                "name": row.name,
                "identifier": row.identifier,
                "contact_email": row.contact_email,
                "matched_user_id": row.user_id,
                "created_estimate": row.created_estimate,
                "last_login_estimate": row.last_login_estimate,
                "reason": row.reason,
                "extra": row.extra,
                "status": row.status,
                "created_at": row.created_at.isoformat(),
            }
            for row in rows
        ]
    })
