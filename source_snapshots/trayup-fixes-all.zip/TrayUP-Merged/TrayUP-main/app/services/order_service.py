import hashlib
import json
import re
import secrets
from datetime import timedelta

from flask import current_app
from sqlalchemy.exc import IntegrityError

from app.extensions import db
from app.models.order import Order, OrderStatus, PaymentStatus
from app.models.order_item import OrderItem
from app.models.order_status_history import OrderStatusHistory
from app.models.payment import Payment, PaymentRecordStatus
from app.services.collection_service import expire_collection_tokens
from app.services.canteen_service import is_accepting_orders
from app.services.errors import OrderError
from app.services.inventory_service import release_reservations, reserve_stock, return_sold_stock
from app.services.pricing_service import normalize_requested_items, price_order
from app.services.time_utils import as_utc, utcnow
from app.services.firebase_service import sync_order_to_firebase

MAX_IDEMPOTENCY_KEY_LENGTH = 64
MAX_CUSTOMER_NAME_LENGTH = 100
MAX_INSTRUCTIONS_LENGTH = 500
# Same rule as the checkout form: an optional +91 and a 10-digit mobile number starting 6-9.
_PHONE_PATTERN = re.compile(r"(?:\+91)?[6-9]\d{9}")
EXPIRY_NOTE = "Payment not completed in time"


def _generate_order_number():
    stamp = utcnow().strftime("%y%m%d")
    return f"TU{stamp}{secrets.token_hex(4).upper()}"


def _hash_token(raw_token):
    # Only the hash is stored. The raw token is returned to the student once.
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()


def _validate_idempotency_key(key):
    if key is None:
        return None
    key = key.strip()
    if not key or len(key) > MAX_IDEMPOTENCY_KEY_LENGTH:
        raise OrderError(
            "INVALID_IDEMPOTENCY_KEY",
            f"Idempotency-Key must be 1 to {MAX_IDEMPOTENCY_KEY_LENGTH} characters.",
        )
    return key


def _find_existing_order(student_id, key):
    return Order.query.filter_by(student_id=student_id, idempotency_key=key).first()


def _optional_text(value, label, max_length):
    """Return the stripped text, or None when the student left it blank."""
    if value is None:
        return None
    if not isinstance(value, str):
        raise OrderError("INVALID_CUSTOMER_DETAILS", f"{label} must be text.", 400)
    value = value.strip()
    if not value:
        return None
    if len(value) > max_length:
        raise OrderError(
            "INVALID_CUSTOMER_DETAILS",
            f"{label} must be {max_length} characters or fewer.",
            400,
        )
    return value


def _validate_customer_details(details):
    """Check the optional checkout details. Returns the cleaned values for storage.

    Phone numbers are stored as +91 followed by the 10 digits, whatever spacing was typed.
    """
    details = details or {}

    name = _optional_text(details.get("customer_name"), "Name", MAX_CUSTOMER_NAME_LENGTH)
    instructions = _optional_text(details.get("instructions"), "Instructions", MAX_INSTRUCTIONS_LENGTH)

    phone = None
    raw_phone = details.get("customer_phone")
    if raw_phone is not None:
        if not isinstance(raw_phone, str):
            raise OrderError("INVALID_CUSTOMER_DETAILS", "Phone number must be text.", 400)
        compact = re.sub(r"[\s-]", "", raw_phone)
        if compact:
            if not _PHONE_PATTERN.fullmatch(compact):
                raise OrderError(
                    "INVALID_CUSTOMER_DETAILS",
                    "Enter a valid 10-digit mobile number.",
                    400,
                )
            phone = "+91" + compact[-10:]

    return {"name": name, "phone": phone, "instructions": instructions}


def _request_fingerprint(requested, customer):
    """Fingerprint of what the order asks for. The order of items does not matter."""
    canonical = json.dumps(
        {
            "items": sorted(requested),
            "customer_name": customer["name"],
            "customer_phone": customer["phone"],
            "instructions": customer["instructions"],
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _matching_existing_order(existing, requested, fingerprint):
    """Return the order for a reused key if it asks for the same thing, otherwise refuse."""
    if existing.request_fingerprint is not None:
        same_request = existing.request_fingerprint == fingerprint
    else:
        # Orders made before fingerprints were stored: compare the items only.
        same_request = dict(requested) == {item.menu_item_id: item.quantity for item in existing.items}

    if not same_request:
        raise OrderError(
            "IDEMPOTENCY_KEY_REUSED",
            "This order was already sent with different items or details. Please place a new order.",
            409,
        )
    return existing


def payment_window_closed(order, now=None):
    """True once an unpaid order has waited longer than ORDER_PAYMENT_EXPIRY_MINUTES."""
    now = now or utcnow()
    minutes = current_app.config["ORDER_PAYMENT_EXPIRY_MINUTES"]
    return as_utc(order.created_at) <= now - timedelta(minutes=minutes)


def expire_order(order, now=None):
    """Cancel one unpaid order and free its held stock. The caller must commit."""
    now = now or utcnow()
    previous_status = order.order_status

    order.order_status = OrderStatus.CANCELLED
    order.payment_status = PaymentStatus.FAILED
    release_reservations(order.id)

    db.session.add(OrderStatusHistory(
        order_id=order.id,
        previous_status=previous_status,
        new_status=OrderStatus.CANCELLED,
        changed_by=None,  # System change, not a staff member
        changed_at=now,
        notes=EXPIRY_NOTE,
    ))


def expire_unpaid_orders():
    """Cancel every unpaid order whose payment window has closed. Returns how many.

    Paid orders are never touched. Runs lazily before each new order, and from the
    `expire-orders` CLI command. The whole sweep is one transaction, so a failure
    changes nothing.
    """
    now = utcnow()
    candidates = (
        Order.query.filter(
            Order.order_status == OrderStatus.PENDING_PAYMENT,
            Order.payment_status == PaymentStatus.PENDING,
        )
        .with_for_update()
        .all()
    )

    try:
        expired = 0
        for order in candidates:
            if payment_window_closed(order, now):
                expire_order(order, now)
                expired += 1
        db.session.commit()
        return expired
    except Exception:
        db.session.rollback()
        raise


def _sweep_expired_orders_safely():
    """Free stock held by expired orders before a new order is priced.

    If the sweep fails, students can still order. Their order may just see less
    free stock until the next sweep. The failure is logged.
    """
    try:
        expire_unpaid_orders()
    except Exception:
        current_app.logger.exception("Could not expire unpaid orders before creating a new order.")


def create_order(student_id, raw_items, idempotency_key=None, customer_details=None):
    """Create a pending_payment order and reserve its stock in one transaction.

    customer_details is an optional dict with customer_name, customer_phone and instructions.

    Returns (order, raw_tracking_token). raw_tracking_token is None when an existing
    order is returned for a retried key, because the raw token was shown the first time.
    A reused key with different items or details raises IDEMPOTENCY_KEY_REUSED.
    """
    key = _validate_idempotency_key(idempotency_key)
    customer = _validate_customer_details(customer_details)
    requested = normalize_requested_items(raw_items)
    fingerprint = _request_fingerprint(requested, customer)

    if key:
        existing = _find_existing_order(student_id, key)
        if existing:
            return _matching_existing_order(existing, requested, fingerprint), None

    if not is_accepting_orders():
        raise OrderError(
            "CANTEEN_CLOSED",
            "The canteen is not accepting new orders right now.",
            409,
        )

    _sweep_expired_orders_safely()

    priced = price_order(requested)
    raw_token = secrets.token_urlsafe(32)

    order = Order(
        order_number=_generate_order_number(),
        student_id=student_id,
        idempotency_key=key,
        customer_name=customer["name"],
        customer_phone=customer["phone"],
        instructions=customer["instructions"],
        request_fingerprint=fingerprint,
        subtotal_paise=priced.subtotal_paise,
        discount_paise=priced.discount_paise,
        tax_paise=priced.tax_paise,
        total_paise=priced.total_paise,
        payment_status=PaymentStatus.PENDING,
        order_status=OrderStatus.PENDING_PAYMENT,
        tracking_token_hash=_hash_token(raw_token),
    )

    for line in priced.lines:
        order.items.append(
            OrderItem(
                menu_item_id=line.menu_item_id,
                item_name_snapshot=line.item_name,
                unit_price_snapshot_paise=line.unit_price_paise,
                quantity=line.quantity,
                line_total_paise=line.line_total_paise,
            )
        )

    try:
        db.session.add(order)
        db.session.flush()  # Assigns order.id, which the stock reservations need.
        reserve_stock(order.id, priced.lines)
        db.session.commit()
    except IntegrityError:
        # A parallel request with the same key may have won the race.
        db.session.rollback()
        if key:
            existing = _find_existing_order(student_id, key)
            if existing:
                return _matching_existing_order(existing, requested, fingerprint), None
        raise OrderError(
            "ORDER_CREATE_FAILED",
            "Could not create the order. Please try again.",
            500,
        )
    except Exception:
        # Also covers OrderError from reserve_stock. The order and any partial holds are rolled back.
        db.session.rollback()
        raise

    committed_order = db.session.get(Order, order.id)
    if committed_order is not None:
        sync_order_to_firebase(committed_order)
    return committed_order or order, raw_token


def cancel_order(order_id, staff_user_id, reason):
    """Admin cancels an order. Returns (order, refund_required).

    Unpaid orders free their held stock. Paid orders get their sold stock back, and
    their money is flagged REFUND_REQUIRED until an admin refunds it. In both cases
    the collection code stops working immediately.
    """
    try:
        order = Order.query.filter_by(id=order_id).with_for_update().first()
        if order is None:
            raise OrderError("ORDER_NOT_FOUND", "Order not found.", 404)

        if order.order_status == OrderStatus.COLLECTED:
            raise OrderError(
                "ORDER_ALREADY_COLLECTED",
                "This order has already been collected and cannot be cancelled.",
                409,
            )
        if order.order_status == OrderStatus.CANCELLED:
            raise OrderError("ALREADY_CANCELLED", "This order is already cancelled.", 409)

        now = utcnow()
        previous_status = order.order_status

        release_reservations(order.id)
        return_sold_stock(order.id)
        expire_collection_tokens(order.id, now)

        captured_payments = Payment.query.filter(
            Payment.order_id == order.id,
            Payment.status.in_([PaymentRecordStatus.PAID, PaymentRecordStatus.PARTIALLY_REFUNDED]),
        ).all()
        for payment in captured_payments:
            payment.status = PaymentRecordStatus.REFUND_REQUIRED
        refund_required = bool(captured_payments)

        # Paid and partly refunded orders keep their payment status. Only unpaid orders change.
        if order.payment_status == PaymentStatus.PENDING:
            order.payment_status = PaymentStatus.FAILED

        order.order_status = OrderStatus.CANCELLED
        db.session.add(OrderStatusHistory(
            order_id=order.id,
            previous_status=previous_status,
            new_status=OrderStatus.CANCELLED,
            changed_by=staff_user_id,
            changed_at=now,
            notes=reason,
        ))

        db.session.commit()
        committed_order = db.session.get(Order, order.id)
        if committed_order is not None:
            sync_order_to_firebase(committed_order)
        return committed_order or order, refund_required

    except Exception:
        db.session.rollback()
        raise
