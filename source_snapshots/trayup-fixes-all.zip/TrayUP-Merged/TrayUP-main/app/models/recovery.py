from app.extensions import db
from app.models.order import utcnow


class PasswordRecoveryChallenge(db.Model):
    """One password-recovery attempt: a hashed one-time code, then a hashed single-use reset token.

    The raw code is sent by email and never stored. The raw reset token is returned once, after the
    code is verified, and only its hash is stored.
    """

    __tablename__ = "password_recovery_challenges"

    __table_args__ = (
        db.CheckConstraint("attempts >= 0", name="ck_password_recovery_attempts_non_negative"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)

    # HMAC of the code, keyed with the app secret. 6-digit codes are too few to hash alone.
    code_hash = db.Column(db.String(64), nullable=False)
    attempts = db.Column(db.Integer, nullable=False, default=0)

    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    last_sent_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    expires_at = db.Column(db.DateTime(timezone=True), nullable=False)
    # Set once the code is used, replaced by a newer code, or locked after too many wrong tries.
    code_consumed_at = db.Column(db.DateTime(timezone=True), nullable=True)

    # Set when the code (or a backup recovery code) is accepted. Hash of the one-time reset token.
    reset_token_hash = db.Column(db.String(64), nullable=True, unique=True)
    reset_expires_at = db.Column(db.DateTime(timezone=True), nullable=True)
    used_at = db.Column(db.DateTime(timezone=True), nullable=True)


class RecoveryCode(db.Model):
    """A backup recovery code. Only an HMAC of the normalized code is stored, and each code works once."""

    __tablename__ = "recovery_codes"

    __table_args__ = (
        db.UniqueConstraint("user_id", "code_hash", name="uq_recovery_codes_user_code"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    code_hash = db.Column(db.String(64), nullable=False)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    used_at = db.Column(db.DateTime(timezone=True), nullable=True)


class AccountRecoveryRequest(db.Model):
    """A request from someone who cannot reach their email or phone. Reviewed by staff, never auto-approved."""

    __tablename__ = "account_recovery_requests"

    id = db.Column(db.Integer, primary_key=True)
    ref = db.Column(db.String(20), nullable=False, unique=True, index=True)
    # Set only when the identifier matches an account. The submitter is never told either way.
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True, index=True)

    name = db.Column(db.String(100), nullable=False)
    identifier = db.Column(db.String(120), nullable=False)
    contact_email = db.Column(db.String(120), nullable=False)
    created_estimate = db.Column(db.String(100), nullable=True)
    last_login_estimate = db.Column(db.String(100), nullable=True)
    reason = db.Column(db.String(1000), nullable=False)
    extra = db.Column(db.String(1000), nullable=True)

    status = db.Column(db.String(20), nullable=False, default="pending", index=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
