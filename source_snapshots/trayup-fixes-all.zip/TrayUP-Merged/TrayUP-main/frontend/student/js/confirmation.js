
    document.getElementById("app-header").innerHTML = trayComponents.header();
    const order = trayStorage.get("trayup-last-order", null);
    const data = order && order.data ? order.data : {};
    const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
    })[character]);
    const paid = ["paid", "captured", "completed", "success"].includes(String(data.payment_status || "").toLowerCase());
    if (paid) {
      const params = new URLSearchParams({ receipt: data.order_number || "Pending" });
      if (data.id) params.set("order", String(data.id));
      window.location.replace(`./order-placed-animation.html?${params}`);
    }
    document.getElementById("receipt-number").textContent = escapeHtml(data.order_number || "Pending");
    document.getElementById("confirmation-name").textContent = escapeHtml(data.student_name || "Not provided");
    document.getElementById("confirmation-phone").textContent = escapeHtml(data.phone_number || "Not provided");
    document.getElementById("confirmation-payment").textContent = escapeHtml(data.payment_provider || (data.payment_method === "cash" ? "Cash on pickup" : "Online"));
    document.getElementById("confirmation-instructions").textContent = escapeHtml(data.instructions || "No special instructions");
    if (!paid) {
      document.getElementById("payment-progress").classList.remove("complete");
      document.getElementById("payment-progress").classList.add("active");
      document.getElementById("confirmation-copy").textContent = "Your order is confirmed. Pay at the counter to complete payment.";
    }
    const items = Array.isArray(data.items) ? data.items : [];
    document.getElementById("confirmation-food-track").innerHTML = items.length ? items.map((item) => `
      <article class="confirmation-food-card">
        <img src="${escapeHtml(item.image || "")}" alt="${escapeHtml(item.name || "Food")}" loading="eager">
        <div><strong>${escapeHtml(item.name || "Food")}</strong><span>Qty ${Number(item.qty || item.quantity || 1)}</span></div>
      </article>
    `).join("") : '<p style="color:var(--muted)">No food items found.</p>';
  