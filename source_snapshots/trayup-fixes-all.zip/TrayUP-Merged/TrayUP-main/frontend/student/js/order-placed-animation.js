(function () {
  "use strict";

  /* ---------- Helpers ---------- */
  const $ = (selector) => document.querySelector(selector);
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const eo3 = (x) => 1 - Math.pow(1 - clamp(x), 3);
  const eob = (x) => { x = clamp(x); return 1 + 2.9 * Math.pow(x - 1, 3) + 1.9 * Math.pow(x - 1, 2); };
  const spring = (x) => (x <= 0 ? 0 : 1 - Math.exp(-6 * x) * Math.cos(16 * x));
  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
  }[c]));
  const rupees = (paise) => "₹" + ((Number(paise) || 0) / 100).toLocaleString("en-IN", {
    minimumFractionDigits: 2, maximumFractionDigits: 2
  });

  /* ---------- Which order this page shows ----------
     checkout and confirmation pass the order id and its receipt number. Older links only have the
     receipt number, so the page looks it up in the student's recent orders. */
  const query = new URLSearchParams(location.search);
  const receipt = query.get("receipt") || "";
  const orderId = Number.parseInt(query.get("order") || "", 10);
  const hasOrderId = Number.isInteger(orderId) && orderId > 0;

  /* ---------- The four real stages of a canteen order ----------
     Each stage is one order_status from the server. The last stage is the handover at the counter. */
  const STEPS = [
    {
      status: "received", label: "Order received", message: "Your order is with the kitchen.",
      icon: '<path d="M5 12.5l4.2 4.2L19 7"/>'
    },
    {
      status: "preparing", label: "Preparing", message: "The kitchen is preparing your order.",
      icon: '<path d="M3 18h18M5 18a7 7 0 0114 0M12 8V6"/>'
    },
    {
      status: "ready", label: "Ready to collect", message: "Your order is ready. Collect it at the counter.",
      icon: '<path d="M6 16V11a6 6 0 0112 0v5l1.5 2h-15zM10 20a2 2 0 004 0"/>'
    },
    {
      status: "collected", label: "Collected", message: "Collected. Enjoy your meal!",
      icon: '<path d="M6 8h12l-1 12H7zM9 8V6a3 3 0 016 0v2"/>'
    }
  ];
  const TERMINAL = new Set(["collected", "cancelled"]);
  const POLL_MS = 5000;
  const RETRY_MS = 10000;

  /* ---------- Page elements ---------- */
  const h1 = $("#h1");
  ["ORDER PLACED", "SUCCESSFULLY!"].forEach((word, lineIndex) => {
    const line = document.createElement("span");
    line.className = "ln";
    [...word].forEach((character, i) => {
      const span = document.createElement("span");
      span.className = "l";
      span.textContent = character;
      span.style.setProperty("--i", i + lineIndex * 8);
      line.appendChild(span);
    });
    h1.appendChild(line);
  });

  $("#steps").innerHTML = STEPS.map((step) =>
    `<div class="st"><div class="ic"><svg viewBox="0 0 24 24">${step.icon}</svg></div>${step.label}</div>`
  ).join("");
  const stepEls = [...document.querySelectorAll(".st")];

  function setStep(index) {
    stepEls.forEach((el, i) => {
      el.classList.toggle("done", i <= index);
      el.classList.toggle("now", i === index && index < STEPS.length - 1);
    });
    $("#fill").style.width = (index < 0 ? 0 : (index / (STEPS.length - 1)) * 100) + "%";
  }

  $("#copy").textContent = receipt || "—";
  $("#copy").addEventListener("click", () => {
    const text = $("#copy").textContent;
    if (text && text !== "—") {
      try { navigator.clipboard.writeText(text); } catch (_) {}
    }
    $("#copied").textContent = "Copied";
    setTimeout(() => { $("#copied").textContent = "Tap to copy"; }, 1800);
  });

  let toastTimer;
  function toast(message) {
    const el = $("#toast");
    el.textContent = message;
    el.classList.add("on");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("on"), 2600);
  }

  // Ripple on button press, as on the rest of the site.
  document.querySelectorAll(".btn").forEach((button) => button.addEventListener("click", (event) => {
    const r = button.getBoundingClientRect();
    const d = Math.max(r.width, r.height) * 2.2;
    const span = document.createElement("span");
    span.className = "rip";
    span.style.cssText = `width:${d}px;height:${d}px;left:${(event.clientX || r.left + r.width / 2) - r.left - d / 2}px;top:${(event.clientY || r.top + r.height / 2) - r.top - d / 2}px`;
    button.appendChild(span);
    span.onanimationend = () => span.remove();
  }));

  /* ---------- Real order data ---------- */
  function renderOrder(order) {
    $("#copy").textContent = order.order_number || receipt || "—";
    const items = Array.isArray(order.items) ? order.items : [];
    $("#items").innerHTML = items.length
      ? items.map((item) =>
          `<li><span>${Math.max(1, Number(item.quantity) || 1)} × ${escapeHtml(item.item_name || "Item")}</span>` +
          `<span>${rupees(item.line_total_paise)}</span></li>`
        ).join("")
      : "<li>No items found</li>";
    $("#total").textContent = rupees(order.total_paise);

    if (order.order_status === "cancelled") {
      setStep(-1);
      $("#sub").textContent = "This order was cancelled.";
      $("#status").textContent = "This order was cancelled.";
      return;
    }

    if (order.payment_status !== "paid" || order.order_status === "pending_payment") {
      setStep(-1);
      $("#sub").textContent = "We are waiting for the payment to be confirmed.";
      $("#status").textContent = "Waiting for payment confirmation…";
      return;
    }

    $("#sub").textContent = "Payment received.";
    const index = STEPS.findIndex((step) => step.status === order.order_status);
    setStep(index);
    $("#status").textContent = index >= 0 ? STEPS[index].message : "Checking your order status…";

    if (lastStatus !== null && lastStatus !== order.order_status && index >= 0) {
      toast(STEPS[index].message);
    }
    lastStatus = order.order_status;
  }

  let lastStatus = null;

  async function fetchOrder() {
    if (hasOrderId) {
      const body = await trayApi.get(`/orders/${orderId}`);
      return body.data;
    }
    if (!receipt) throw Object.assign(new Error("No order"), { status: 404 });
    for (let page = 1; page <= 5; page++) {
      const body = await trayApi.get(`/orders?page=${page}&per_page=50`);
      const match = (body.data.orders || []).find((order) => order.order_number === receipt);
      if (match) return match;
      if (!body.data.pagination || !body.data.pagination.has_next) break;
    }
    throw Object.assign(new Error("Order not found"), { status: 404 });
  }

  let pollTimer = null;

  async function refresh() {
    clearTimeout(pollTimer);
    try {
      const order = await fetchOrder();
      renderOrder(order);
      if (!TERMINAL.has(order.order_status)) pollTimer = setTimeout(refresh, POLL_MS);
    } catch (error) {
      if (error.status === 401) {
        setStep(-1);
        $("#sub").textContent = "Sign in to see your order.";
        $("#status").textContent = "Sign in to your student account to follow this order.";
      } else if (error.status === 404) {
        setStep(-1);
        $("#sub").textContent = "We could not find this order.";
        $("#status").textContent = "Check the order from My Orders.";
      } else {
        $("#status").textContent = "Order status is unavailable right now. Retrying…";
        pollTimer = setTimeout(refresh, RETRY_MS);
      }
    }
  }

  /* ---------- Page reveal ---------- */
  const rvs = [...document.querySelectorAll(".rv")];
  const timers = [];
  const later = (fn, ms) => timers.push(setTimeout(fn, ms));
  function showTitle() { h1.classList.add("on"); }
  function showPanel() { rvs.forEach((el, i) => later(() => el.classList.add("on"), i * 180)); }
  function hidePage() {
    timers.splice(0).forEach(clearTimeout);
    h1.classList.remove("on");
    rvs.forEach((el) => el.classList.remove("on"));
  }

  /* ---------- 3D success badge ---------- */
  let R = null, S = null, cam = null, badge = null, run = false, st = null, t0 = 0, last = 0;
  let startScene = null, stopScene = null;
  const speed = reduce ? 3 : 1;

  try {
    const stage = $("#stage"), canvas = $("#c");
    R = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: "high-performance" });
    R.setPixelRatio(Math.min(devicePixelRatio, 2));
    R.outputEncoding = THREE.sRGBEncoding;
    R.toneMapping = THREE.ACESFilmicToneMapping;
    R.toneMappingExposure = 1.15;
    S = new THREE.Scene();
    cam = new THREE.PerspectiveCamera(35, 1, 0.1, 50);
    S.add(new THREE.AmbientLight(0xffe2b8, 0.6));
    const key = new THREE.DirectionalLight(0xfff0d6, 1.7); key.position.set(3, 6, 5); S.add(key);
    const rim = new THREE.DirectionalLight(0xe6bc63, 1.3); rim.position.set(-4, 3, -4); S.add(rim);
    const glowL = new THREE.PointLight(0xffc766, 0, 7); glowL.position.set(0, 1.9, 0.9); S.add(glowL);

    const dot = (() => {
      const c = document.createElement("canvas"); c.width = c.height = 64;
      const g = c.getContext("2d"), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(0.3, "rgba(255,255,255,.45)"); gr.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
      return new THREE.CanvasTexture(c);
    })();
    const M = (c, r = 0.5, m = 0.1, o = {}) => new THREE.MeshStandardMaterial(Object.assign({ color: c, roughness: r, metalness: m }, o));
    const mChoc = M(0x3a2115, 0.5, 0.12), mGold = M(0xe0b25a, 0.28, 0.85);

    // Halo rings and glow behind the badge
    const halo = new THREE.Group(); halo.position.set(0, 1.9, -1.2); S.add(halo);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(2.45, 0.035, 16, 160), new THREE.MeshBasicMaterial({ color: 0xf1cd7a, transparent: true, opacity: 0 }));
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(2.72, 0.012, 8, 160), new THREE.MeshBasicMaterial({ color: 0xf1cd7a, transparent: true, opacity: 0 }));
    const gl = new THREE.Sprite(new THREE.SpriteMaterial({ map: dot, color: 0xffd98a, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }));
    gl.scale.set(8, 8, 1);
    halo.add(ring, ring2, gl);

    // Success badge: a dark disc with a gold check
    badge = new THREE.Group(); badge.position.set(0, 1.9, 0.3); badge.visible = false; S.add(badge);
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.14, 48), mChoc); disc.rotation.x = Math.PI / 2; badge.add(disc);
    const rimM = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.05, 12, 48), mGold); badge.add(rimM);
    const sh = new THREE.Shape();
    [[-0.5, 0.02], [-0.36, -0.12], [-0.14, 0.1], [0.36, -0.4], [0.5, -0.26], [-0.14, 0.38]]
      .forEach((p, i) => (i ? sh.lineTo(p[0], p[1]) : sh.moveTo(p[0], p[1])));
    const chk = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth: 0.12, bevelEnabled: true, bevelSize: 0.025, bevelThickness: 0.025, bevelSegments: 3 }), mGold);
    chk.position.set(0, -0.02, 0.08); badge.add(chk);

    // Ambient particles that drift and react to the pointer
    const N = 110, pp = new Float32Array(N * 3), pv = new Float32Array(N * 3), ph = [], home = [];
    for (let i = 0; i < N; i++) {
      const h = [(Math.random() - 0.5) * 7, -0.3 + Math.random() * 4.8, -1 + Math.random() * 2.6];
      home.push(h); ph.push(Math.random() * 6); pp.set(h, i * 3);
    }
    const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pp, 3));
    const pm = new THREE.PointsMaterial({ size: 0.11, map: dot, color: 0xf1cd7a, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
    S.add(new THREE.Points(pg, pm));

    // Sparkle burst and confetti
    const SN = 90, sp = new Float32Array(SN * 3), sv = new Float32Array(SN * 3), scol = new Float32Array(SN * 3), slife = new Float32Array(SN);
    const sg = new THREE.BufferGeometry();
    sg.setAttribute("position", new THREE.BufferAttribute(sp, 3));
    sg.setAttribute("color", new THREE.BufferAttribute(scol, 3));
    S.add(new THREE.Points(sg, new THREE.PointsMaterial({ size: 0.16, map: dot, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })));
    const CN = 90, cm = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.09, 0.17), new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }), CN);
    const cp = [], cv = [], cr = [], crv = [], cl = [], dm = new THREE.Object3D(), pal = [0xe6bc63, 0xf6ead4, 0xc98b4b, 0x5a3422, 0xf1cd7a];
    for (let i = 0; i < CN; i++) {
      cp.push(new THREE.Vector3(0, -9, 0)); cv.push(new THREE.Vector3()); cr.push(new THREE.Vector3()); crv.push(new THREE.Vector3()); cl.push(0);
      cm.setColorAt(i, new THREE.Color(pal[i % 5]));
    }
    cm.frustumCulled = false; S.add(cm);

    function burst() {
      for (let i = 0; i < SN; i++) {
        const a = Math.random() * 6.28, u = Math.random(), power = 2 + Math.random() * 3.5;
        sp.set([(Math.random() - 0.5) * 1.2, 0.6, (Math.random() - 0.5) * 1.2], i * 3);
        sv.set([Math.cos(a) * power * 0.7, 1.5 + u * 4, Math.sin(a) * power * 0.5], i * 3);
        slife[i] = 0.7 + Math.random() * 0.9;
      }
      for (let i = 0; i < CN; i++) {
        const a = Math.random() * 6.28, s = 1.5 + Math.random() * 3;
        cp[i].set((Math.random() - 0.5) * 1.2, 0.6, (Math.random() - 0.5) * 1.2);
        cv[i].set(Math.cos(a) * s, 4 + Math.random() * 4.5, Math.sin(a) * s * 0.6);
        cr[i].set(Math.random() * 6, Math.random() * 6, 0);
        crv[i].set((Math.random() - 0.5) * 12, (Math.random() - 0.5) * 12, (Math.random() - 0.5) * 8);
        cl[i] = 2.6 + Math.random() * 0.9;
      }
    }

    // Pointer tracking for the particle field
    const ptr = new THREE.Vector2(9, 9), ray = new THREE.Raycaster(), pl = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0), mw = new THREE.Vector3(99, 99, 0);
    addEventListener("pointermove", (e) => {
      const r = stage.getBoundingClientRect();
      ptr.set((e.clientX - r.left) / r.width * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    });
    addEventListener("pointerleave", () => ptr.set(9, 9));

    function resize() {
      const w = stage.clientWidth, h = stage.clientHeight;
      R.setSize(w, h, false);
      cam.aspect = w / h;
      const z = 9 * Math.max(1, 0.95 / cam.aspect);
      cam.position.set(0, 2.5 + (z - 9) * 0.2, z);
      cam.lookAt(0, 1.55, 0);
      cam.updateProjectionMatrix();
    }
    new ResizeObserver(resize).observe(stage);
    resize();

    function sceneTick() {
      if (!run) return;
      const now = performance.now(), dt = Math.min(0.05, (now - last) / 1000) * speed;
      last = now;
      const t = (now - t0) / 1000 * speed;
      st.time += dt;

      // Halo fades in
      const rp = eo3(t / 1.3);
      ring.material.opacity = rp; ring2.material.opacity = rp * 0.4; gl.material.opacity = rp * 0.4;
      halo.scale.setScalar(lerp(0.6, 1, rp));
      ring2.rotation.z = t * 0.1;
      pm.opacity = eo3((t - 0.8) / 1.5) * 0.85;

      // Badge springs in, then the burst, title and panel follow
      const kc = t - 0.15;
      badge.visible = kc > 0;
      if (kc > 0) {
        badge.scale.setScalar(Math.max(0.001, spring(kc)));
        badge.rotation.y = (1 - clamp(kc / 0.9)) * Math.PI * 2 + Math.sin(st.time * 1.2) * 0.12;
        badge.position.y = 1.9 + Math.sin(st.time * 1.5) * 0.06;
        glowL.intensity = 3.5 * eo3(kc / 0.5);
        if (!st.burst && kc > 0.05) { st.burst = true; burst(); }
      }
      if (!st.title && t > 0.4) { st.title = true; showTitle(); }
      if (!st.panel && t > 1.0) { st.panel = true; showPanel(); }

      // Ambient particles
      ray.setFromCamera(ptr, cam);
      if (!ray.ray.intersectPlane(pl, mw)) mw.set(99, 99, 0);
      const f = dt * 60;
      for (let i = 0; i < N; i++) {
        const j = i * 3, h = home[i];
        const tx = h[0] + Math.sin(st.time * 0.5 + ph[i]) * 0.2, ty = h[1] + Math.cos(st.time * 0.4 + ph[i]) * 0.25;
        pv[j] += (tx - pp[j]) * 0.012 * f; pv[j + 1] += (ty - pp[j + 1]) * 0.012 * f; pv[j + 2] += (h[2] - pp[j + 2]) * 0.012 * f;
        const dx = pp[j] - mw.x, dy = pp[j + 1] - mw.y, d = Math.hypot(dx, dy);
        if (d < 1.5 && d > 0.001) { const k = (1.5 - d) * 0.07 * f; pv[j] += dx / d * k; pv[j + 1] += dy / d * k; }
        pv[j] *= 0.93; pv[j + 1] *= 0.93; pv[j + 2] *= 0.93;
        pp[j] += pv[j] * f; pp[j + 1] += pv[j + 1] * f; pp[j + 2] += pv[j + 2] * f;
      }
      pg.attributes.position.needsUpdate = true;

      // Sparkles
      for (let i = 0; i < SN; i++) {
        const j = i * 3;
        if (slife[i] > 0) {
          slife[i] -= dt; sv[j + 1] -= 3 * dt;
          sp[j] += sv[j] * dt; sp[j + 1] += sv[j + 1] * dt; sp[j + 2] += sv[j + 2] * dt;
          const b = clamp(slife[i] * 1.4) * (0.6 + 0.4 * Math.sin(st.time * 30 + i));
          scol[j] = b; scol[j + 1] = 0.8 * b; scol[j + 2] = 0.42 * b;
        } else {
          scol[j] = scol[j + 1] = scol[j + 2] = 0;
        }
      }
      sg.attributes.position.needsUpdate = sg.attributes.color.needsUpdate = true;

      // Confetti
      for (let i = 0; i < CN; i++) {
        if (cl[i] > 0) {
          cl[i] -= dt;
          cv[i].y -= 7 * dt; cv[i].multiplyScalar(1 - 1.2 * dt * 0.5);
          cp[i].addScaledVector(cv[i], dt); cr[i].addScaledVector(crv[i], dt);
          dm.position.copy(cp[i]); dm.rotation.set(cr[i].x, cr[i].y, cr[i].z); dm.scale.setScalar(clamp(cl[i] * 2.5));
        } else {
          dm.position.set(0, -20, 0); dm.scale.setScalar(0.0001);
        }
        dm.updateMatrix();
        cm.setMatrixAt(i, dm.matrix);
      }
      cm.instanceMatrix.needsUpdate = true;
      R.render(S, cam);
    }

    startScene = function () {
      run = true;
      st = { time: 0, burst: false, title: false, panel: false };
      for (let i = 0; i < CN; i++) cl[i] = 0;
      slife.fill(0);
      t0 = performance.now(); last = t0;
      R.setAnimationLoop(sceneTick);
    };
    stopScene = function () {
      run = false;
      badge.visible = false;
    };
  } catch (err) {
    console.warn(err);
    R = null;
    startScene = null;
    stopScene = null;
    const canvas = $("#c");
    if (canvas) canvas.style.display = "none";
  }

  /* ---------- Intro: light gathers, impact frames, check mark ---------- */
  const intro = $("#intro"), ic = $("#ic"), ix = ic.getContext("2d"), isp = reduce ? 2 : 1;
  let IW, IH, DPR, IR, ip, lines, sparks, spawned, rid, it0, fired;

  const sizeIntro = () => {
    DPR = Math.min(devicePixelRatio, 2); IW = innerWidth; IH = innerHeight;
    ic.width = IW * DPR; ic.height = IH * DPR;
    IR = Math.min(Math.max(Math.min(IW, IH) * 0.13, 64), 120);
  };
  addEventListener("resize", sizeIntro);

  function seedIntro() {
    const n = reduce ? 120 : 300, m = Math.hypot(IW, IH) * 0.6;
    ip = [];
    for (let i = 0; i < n; i++) ip.push({ a: Math.random() * 6.283, r: m * (0.25 + Math.random() * 0.75), d: Math.random(), s: 0.8 + Math.random() * 1.8, w: (Math.random() < 0.5 ? -1 : 1) * (1.5 + Math.random() * 2) });
    lines = [];
    for (let i = 0; i < 30; i++) lines.push({ a: i / 30 * 6.283 + Math.random() * 0.1, l: 1.5 + Math.random() * 3.5, w: 1 + Math.random() * 2.5 });
    sparks = []; spawned = 0;
  }

  function checkMark(cx, cy, s, p) {
    const P = [[-0.45, 0.02], [-0.12, 0.34], [0.5, -0.34]], L1 = 0.47, L2 = 0.9, d = p * (L1 + L2);
    ix.beginPath(); ix.moveTo(cx + P[0][0] * s, cy + P[0][1] * s);
    const a = Math.min(d, L1) / L1;
    ix.lineTo(cx + (P[0][0] + (P[1][0] - P[0][0]) * a) * s, cy + (P[0][1] + (P[1][1] - P[0][1]) * a) * s);
    if (d > L1) {
      const b = (d - L1) / L2;
      ix.lineTo(cx + (P[1][0] + (P[2][0] - P[1][0]) * b) * s, cy + (P[1][1] + (P[2][1] - P[1][1]) * b) * s);
    }
  }

  function introFrame(now) {
    if (fired) return;
    const T = (now - it0) / 1000 * isp, Ti = 2.5, E = Ti + 0.13 + 1.7, cx = IW / 2, cy = IH / 2, k = T - Ti;
    if (T >= E) { finishIntro(); return; }
    rid = requestAnimationFrame(introFrame);
    ix.setTransform(DPR, 0, 0, DPR, 0, 0); ix.globalCompositeOperation = "source-over";

    // Impact frame 1: full flash
    if (k >= 0 && k < 0.06) { ix.fillStyle = "#fff1cf"; ix.fillRect(0, 0, IW, IH); return; }
    // Impact frame 2: inverted silhouette of the check
    if (k >= 0.06 && k < 0.13) {
      ix.fillStyle = "#f6ead4"; ix.fillRect(0, 0, IW, IH);
      ix.strokeStyle = "#1a0d07"; ix.lineWidth = IR * 0.5; ix.lineCap = ix.lineJoin = "round";
      checkMark(cx, cy, IR * 2.6, 1); ix.stroke(); return;
    }

    const charge = k < 0 ? clamp((T - 1.9) / 0.6) * 3 : 0;
    const sh = k >= 0.13 ? Math.max(0, 1 - (k - 0.13) / 0.4) * 16 : charge;
    ix.setTransform(DPR, 0, 0, DPR, (Math.random() - 0.5) * sh * DPR, (Math.random() - 0.5) * sh * DPR);
    ix.fillStyle = k < 0 ? "rgba(13,7,4,.22)" : "rgba(13,7,4,.38)";
    ix.fillRect(-30, -30, IW + 60, IH + 60);
    ix.globalCompositeOperation = "lighter";
    const p = clamp((T - 0.3) / 2.2), kk = k - 0.13;

    if (k < 0) {
      const g = 16 + p * p * p * 120 + Math.sin(T * 18) * charge * 3, gr = ix.createRadialGradient(cx, cy, 0, cx, cy, g);
      gr.addColorStop(0, `rgba(255,236,190,${0.3 + 0.7 * p})`); gr.addColorStop(0.35, `rgba(240,190,95,${0.35 * p + 0.05})`); gr.addColorStop(1, "rgba(230,188,99,0)");
      ix.fillStyle = gr; ix.beginPath(); ix.arc(cx, cy, g, 0, 6.283); ix.fill();
      for (const s of ip) {
        const pp = clamp((T - 0.3 - s.d * 0.25) / 1.9), e = Math.pow(pp, 2.2), r = s.r * (1 - e), a = s.a + e * s.w;
        ix.fillStyle = `rgba(255,214,130,${0.2 + 0.8 * pp})`; ix.beginPath(); ix.arc(cx + Math.cos(a) * r, cy + Math.sin(a) * r, s.s * (1 + pp), 0, 6.283); ix.fill();
      }
    } else {
      const g = IR * 4, gr = ix.createRadialGradient(cx, cy, 0, cx, cy, g);
      gr.addColorStop(0, `rgba(255,225,160,${0.5 * clamp(1 - kk / 1.3)})`); gr.addColorStop(1, "rgba(230,188,99,0)");
      ix.fillStyle = gr; ix.fillRect(0, 0, IW, IH);
      for (const d of [0, 0.12]) {
        const q = (kk - d) / 0.9;
        if (q > 0 && q < 1) { ix.strokeStyle = `rgba(255,220,150,${1 - q})`; ix.lineWidth = 2 + (1 - q) * 7; ix.beginPath(); ix.arc(cx, cy, IR + eo3(q) * Math.max(IW, IH) * 0.6, 0, 6.283); ix.stroke(); }
      }
      const q = kk / 0.35;
      if (q < 1) {
        ix.lineCap = "round";
        for (const l of lines) {
          const r0 = IR * 1.35 + IR * q * l.l * 0.9, r1 = IR * 1.35 + IR * l.l * eo3(q) * 1.6;
          ix.strokeStyle = `rgba(255,226,165,${1 - q})`; ix.lineWidth = l.w;
          ix.beginPath(); ix.moveTo(cx + Math.cos(l.a) * r0, cy + Math.sin(l.a) * r0); ix.lineTo(cx + Math.cos(l.a) * r1, cy + Math.sin(l.a) * r1); ix.stroke();
        }
      }
      if (!spawned) {
        spawned = 1;
        for (let i = 0; i < 90; i++) { const a = Math.random() * 6.283, v = 250 + Math.random() * 650; sparks.push({ x: cx, y: cy, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: 0.6 + Math.random() * 0.8 }); }
      }
      for (const s of sparks) if (s.l > 0) {
        s.l -= 0.0167 * isp; s.x += s.vx * 0.0167; s.y += s.vy * 0.0167; s.vx *= 0.95; s.vy *= 0.95;
        ix.fillStyle = `rgba(255,214,130,${clamp(s.l * 1.5)})`; ix.beginPath(); ix.arc(s.x, s.y, 1.8, 0, 6.283); ix.fill();
      }
      ix.globalCompositeOperation = "source-over";
      const sc = Math.max(0.001, spring(kk));
      ix.save(); ix.translate(cx, cy); ix.scale(sc, sc); ix.translate(-cx, -cy);
      ix.shadowColor = "rgba(230,188,99,.9)"; ix.shadowBlur = 36; ix.fillStyle = "#2b1710";
      ix.beginPath(); ix.arc(cx, cy, IR, 0, 6.283); ix.fill();
      ix.strokeStyle = "#e6bc63"; ix.lineWidth = IR * 0.06; ix.stroke();
      ix.shadowBlur = 18; ix.lineWidth = IR * 0.17; ix.lineCap = ix.lineJoin = "round";
      checkMark(cx, cy, IR * 1.15, eo3(kk / 0.35)); ix.stroke(); ix.restore();
      const ta = clamp((kk - 0.6) / 0.5);
      if (ta > 0) {
        ix.shadowBlur = 0; ix.fillStyle = `rgba(246,234,212,${ta})`;
        ix.font = `600 ${Math.round(IR * 0.3)}px 'Cormorant Garamond',serif`; ix.textAlign = "center";
        ix.fillText("Order placed", cx, cy + IR * 1.9);
      }
    }
    // Closing flash into the page
    const fa = clamp((T - (E - 0.3)) / 0.3);
    if (fa > 0) { ix.setTransform(DPR, 0, 0, DPR, 0, 0); ix.globalCompositeOperation = "source-over"; ix.fillStyle = `rgba(255,241,207,${fa})`; ix.fillRect(0, 0, IW, IH); }
  }

  function finishIntro() {
    if (fired) return;
    fired = 1;
    cancelAnimationFrame(rid);
    intro.classList.add("out");
    if (startScene) startScene();
    else { showTitle(); showPanel(); }
  }

  function startIntro() {
    hidePage();
    if (stopScene) stopScene();
    intro.classList.remove("out");
    fired = 0;
    sizeIntro(); seedIntro();
    cancelAnimationFrame(rid);
    it0 = performance.now();
    rid = requestAnimationFrame(introFrame);
  }

  $("#skip").addEventListener("click", finishIntro);
  $("#replay").addEventListener("click", startIntro);
  addEventListener("pagehide", () => { clearTimeout(pollTimer); cancelAnimationFrame(rid); });

  startIntro();
  refresh();
})();
