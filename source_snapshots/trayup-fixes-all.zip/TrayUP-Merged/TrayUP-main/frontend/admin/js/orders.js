(function () {
  "use strict";

  // Rows per page. The server enforces the same limit (MAX_PER_PAGE).
  const PER_PAGE = 50;
  const demoMode = new URLSearchParams(window.location.search).get("demo") === "1";

  const body = document.getElementById("orders-body");
  const summary = document.getElementById("orders-summary");
  const pager = document.getElementById("orders-pager");
  const prevButton = document.getElementById("prev-page");
  const nextButton = document.getElementById("next-page");
  const pageLabel = document.getElementById("page-label");

  // Everything the list is filtered and paged by. Each change goes to the server.
  const state = { q: "", orderStatus: "", paymentStatus: "", page: 1, hasPrev: false, hasNext: false };
  let latestRequest = 0;
  let searchTimer = null;

  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
  }[c]));
  const money = (paise) => "₹" + ((Number(paise) || 0) / 100).toLocaleString("en-IN", { maximumFractionDigits: 2 });
  const label = (value) => {
    const text = String(value || "").replace(/_/g, " ").trim();
    return text ? text.charAt(0).toUpperCase() + text.slice(1) : "—";
  };

  // The query string sent to the server. Empty filters are left out, so the first load asks only for the first page.
  function queryString() {
    const params = new URLSearchParams({ per_page: String(PER_PAGE) });
    if (state.page > 1) params.set("page", String(state.page));
    if (state.q) params.set("q", state.q);
    if (state.orderStatus) params.set("order_status", state.orderStatus);
    if (state.paymentStatus) params.set("payment_status", state.paymentStatus);
    return params.toString();
  }

  function rowHtml(order) {
    const student = order.student || {};
    return "<tr><td><strong>" + esc(order.order_number || order.id) + "</strong></td>" +
      "<td>" + esc(student.name || "Guest") +
      (student.email ? '<div class="muted" style="font-size:12px">' + esc(student.email) + "</div>" : "") + "</td>" +
      "<td>" + money(order.total_paise) + "</td>" +
      '<td><span class="status">' + esc(label(order.order_status)) + "</span></td>" +
      "<td>" + esc(label(order.payment_status)) + "</td></tr>";
  }

  function render(data) {
    const orders = Array.isArray(data.orders) ? data.orders : [];
    const info = data.pagination || {};
    state.page = info.page || state.page;
    state.hasPrev = !!info.has_prev;
    state.hasNext = !!info.has_next;

    body.innerHTML = orders.length
      ? orders.map(rowHtml).join("")
      : '<tr><td colspan="5">No matching orders</td></tr>';

    const total = Number(info.total) || 0;
    const pages = Math.max(1, Number(info.pages) || 1);
    summary.textContent = total + (total === 1 ? " order" : " orders") +
      (state.q ? ' matching "' + state.q + '"' : "");
    pageLabel.textContent = "Page " + state.page + " of " + pages;
    prevButton.disabled = !state.hasPrev;
    nextButton.disabled = !state.hasNext;
    pager.style.display = demoMode ? "none" : "flex";
  }

  function errorMessage(error) {
    if (error.status === 401) return "Please sign in to view administrator orders.";
    if (error.status === 403) return "This account does not have administrator access.";
    if (error.status === 400 && error.message) return error.message;
    return "Could not load orders. Please retry.";
  }

  function showError(error) {
    summary.textContent = "";
    body.innerHTML = '<tr><td colspan="5">' + esc(errorMessage(error)) + "</td></tr>";
    prevButton.disabled = true;
    nextButton.disabled = true;
    pageLabel.textContent = "";
  }

  // Demo mode uses fixed sample rows, filtered in the browser with the same rules as the server.
  const DEMO_ORDERS = [
    { order_number: "TUP-4825", student: { name: "Aarav Shah", email: "aarav@example.test" }, total_paise: 31000, order_status: "preparing", payment_status: "paid" },
    { order_number: "TUP-4821", student: { name: "Meera Iyer", email: "meera@example.test" }, total_paise: 22500, order_status: "ready", payment_status: "paid" },
    { order_number: "TUP-4818", student: { name: "Kabir Singh", email: "kabir@example.test" }, total_paise: 28000, order_status: "preparing", payment_status: "paid" },
    { order_number: "TUP-4809", student: { name: "Zoya Khan", email: "zoya@example.test" }, total_paise: 19000, order_status: "collected", payment_status: "paid" }
  ];

  function demoPage() {
    const q = state.q.toLowerCase();
    const orders = DEMO_ORDERS.filter((o) =>
      (!q || (o.order_number + " " + o.student.name + " " + o.student.email).toLowerCase().includes(q)) &&
      (!state.orderStatus || o.order_status === state.orderStatus) &&
      (!state.paymentStatus || o.payment_status === state.paymentStatus));
    return { orders, pagination: { page: 1, pages: 1, total: orders.length, has_prev: false, has_next: false } };
  }

  async function load() {
    const request = ++latestRequest;
    body.innerHTML = '<tr><td colspan="5">Loading…</td></tr>';
    try {
      const data = demoMode ? demoPage() : (await trayApi.get("/admin/orders?" + queryString())).data;
      // A newer request has started since this one, so its answer is out of date.
      if (request !== latestRequest) return;
      render(data || {});
    } catch (error) {
      if (request !== latestRequest) return;
      showError(error);
    }
  }

  if (demoMode) {
    document.querySelector(".table-card").insertAdjacentHTML("beforebegin",
      '<p class="status warning">Read-only demo data</p>');
  }

  const search = document.getElementById("order-search");
  search.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      const next = search.value.trim();
      if (next === state.q) return;
      state.q = next;
      state.page = 1;
      load();
    }, 300);
  });

  document.getElementById("payment-filter").addEventListener("change", (event) => {
    state.paymentStatus = event.target.value;
    state.page = 1;
    load();
  });

  document.getElementById("status-filter").addEventListener("change", (event) => {
    state.orderStatus = event.target.value;
    state.page = 1;
    load();
  });

  prevButton.addEventListener("click", () => {
    if (!state.hasPrev) return;
    state.page -= 1;
    load();
  });

  nextButton.addEventListener("click", () => {
    if (!state.hasNext) return;
    state.page += 1;
    load();
  });

  load();
})();
