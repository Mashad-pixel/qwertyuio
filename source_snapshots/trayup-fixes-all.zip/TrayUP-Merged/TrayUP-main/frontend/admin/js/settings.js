(function () {
  const content = document.querySelector(".admin-content");
  // Stored settings are validated by storage.js. The markup below is static, and
  // saved values are assigned with .value, so they are never parsed as HTML.
  const saved = trayStorage.getCanteenSettings();

  content.innerHTML = `<h1 class="admin-title">Canteen settings</h1><form id="settings-form" class="card" style="max-width:620px;margin-top:22px;padding:22px"><div class="field"><label>Canteen name</label><input id="canteen-name" maxlength="120" required></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:12px"><div class="field"><label>Opening time</label><input id="open-time" type="time" required></div><div class="field"><label>Closing time</label><input id="close-time" type="time" required></div></div><div class="field"><label>Operating status</label><select id="operating-status"><option>Open</option><option>Closed</option></select></div><button class="btn btn-primary" type="submit">Save settings</button></form>`;

  const nameInput = document.getElementById("canteen-name");
  const openInput = document.getElementById("open-time");
  const closeInput = document.getElementById("close-time");
  const statusInput = document.getElementById("operating-status");

  nameInput.value = saved.name;
  openInput.value = saved.open;
  closeInput.value = saved.close;
  statusInput.value = saved.status;

  document.getElementById("settings-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const value = trayStorage.validators.canteenSettings({
      name: nameInput.value.trim(),
      open: openInput.value,
      close: closeInput.value,
      status: statusInput.value
    });
    if (!value) {
      trayNotify("Please check the settings and try again");
      return;
    }
    trayStorage.set("trayup-canteen-settings", value);
    trayNotify("Demo settings saved");
  });
})();
