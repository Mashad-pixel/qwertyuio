"""Reports must count each order on the canteen-local calendar day it was placed.

The canteen is UTC+05:30 (CANTEEN_UTC_OFFSET_MINUTES defaults to 330). An order at 20:00 on
30 November IST is stored as 14:30 UTC on 30 November. Before the fix, the report compared
the raw date against UTC timestamps, so that order fell outside the 30 November report.
"""
import uuid
from datetime import datetime, timedelta, timezone

from app.extensions import db
from app.models.order import Order, OrderStatus
from app.models.payment import Payment
from app.models.refund import Refund, RefundStatus
from app.models.user import UserRole
from tests.test_reports import login_as, make_user, pay  # reuse the paid-order helpers

IST = timezone(timedelta(minutes=330))


def ist(year, month, day, hour=0, minute=0):
    """A canteen-local wall-clock time, as an aware UTC datetime."""
    return datetime(year, month, day, hour, minute, tzinfo=IST).astimezone(timezone.utc)


def place_paid(student, menu, key, quantity, when):
    """Create a paid order, then move its timestamp to `when` (a UTC datetime)."""
    order = pay(student, key, menu, quantity)
    stored = db.session.get(Order, order.id)
    stored.created_at = when
    db.session.commit()
    return stored


def add_refund(order, amount, status=RefundStatus.PROCESSED):
    payment = Payment.query.filter_by(order_id=order.id).one()
    db.session.add(Refund(
        payment_id=payment.id,
        order_id=order.id,
        provider_refund_id=f"rfnd_{uuid.uuid4().hex[:12]}",
        amount_paise=amount,
        status=status,
    ))
    db.session.commit()


def overview(client, query=""):
    return client.get(f"/api/admin/reports/overview{query}").get_json()["data"]


def sales(client, query=""):
    return client.get(f"/api/admin/reports/sales{query}").get_json()["data"]["days"]


def admin(app):
    user = make_user("reports-admin@test.com", UserRole.ADMIN, name="Reports Admin")
    return login_as(app.test_client(), user)


# ---------- Day boundaries ----------

def test_late_evening_order_is_counted_on_its_own_canteen_day(app, student, menu):
    client = admin(app)
    place_paid(student, menu, "samosa", 1, ist(2026, 11, 30, 20, 0))

    data = overview(client, "?from=2026-11-30&to=2026-11-30")

    assert data["total_orders"] == 1
    assert data["gross_revenue_paise"] == 1500


def test_day_edges_follow_canteen_midnight_not_utc(app, student, menu):
    client = admin(app)
    place_paid(student, menu, "tea", 1, ist(2026, 11, 29, 23, 59))   # last minute of the 29th
    place_paid(student, menu, "tea", 1, ist(2026, 11, 30, 0, 0))     # first instant of the 30th
    place_paid(student, menu, "tea", 1, ist(2026, 11, 30, 23, 59))   # last minute of the 30th
    place_paid(student, menu, "tea", 1, ist(2026, 12, 1, 0, 0))      # first instant of 1 Dec

    thirtieth = overview(client, "?from=2026-11-30&to=2026-11-30")
    twenty_ninth = overview(client, "?from=2026-11-29&to=2026-11-29")
    first_dec = overview(client, "?from=2026-12-01&to=2026-12-01")

    assert thirtieth["total_orders"] == 2
    assert twenty_ninth["total_orders"] == 1
    assert first_dec["total_orders"] == 1


def test_to_date_is_inclusive(app, student, menu):
    client = admin(app)
    place_paid(student, menu, "tea", 1, ist(2026, 11, 29, 12, 0))
    place_paid(student, menu, "tea", 1, ist(2026, 11, 30, 12, 0))

    data = overview(client, "?from=2026-11-29&to=2026-11-30")

    assert data["total_orders"] == 2


def test_sales_buckets_orders_by_canteen_local_day(app, student, menu):
    client = admin(app)
    # 00:30 IST on the 30th is still 29 November in UTC. It must land in the 30th bucket.
    place_paid(student, menu, "tea", 1, ist(2026, 11, 30, 0, 30))

    days = sales(client, "?from=2026-11-29&to=2026-11-30")

    assert [day["date"] for day in days] == ["2026-11-30"]
    assert days[0]["orders"] == 1


def test_peak_hours_use_canteen_local_hour(app, student, menu):
    client = admin(app)
    place_paid(student, menu, "tea", 1, ist(2026, 11, 30, 20, 15))

    hours = client.get("/api/admin/reports/peak-hours?from=2026-11-30&to=2026-11-30").get_json()["data"]["hours"]

    by_hour = {row["hour"]: row["orders"] for row in hours}
    assert by_hour[20] == 1
    assert sum(by_hour.values()) == 1


# ---------- Revenue aggregation ----------

def test_daily_sales_add_up_to_the_overview_totals(app, student, menu):
    client = admin(app)
    place_paid(student, menu, "samosa", 2, ist(2026, 11, 29, 13, 0))   # 3000
    place_paid(student, menu, "tea", 3, ist(2026, 11, 30, 9, 0))       # 3000
    place_paid(student, menu, "tea", 1, ist(2026, 11, 30, 19, 0))      # 1000

    query = "?from=2026-11-29&to=2026-11-30"
    totals = overview(client, query)
    days = sales(client, query)

    assert totals["gross_revenue_paise"] == 7000
    assert sum(day["revenue_paise"] for day in days) == totals["gross_revenue_paise"]
    assert sum(day["orders"] for day in days) == totals["paid_orders"] == 3
    assert [day["revenue_paise"] for day in days] == [3000, 4000]


def test_average_order_value_and_completion_use_only_the_range(app, student, menu):
    client = admin(app)
    inside_a = place_paid(student, menu, "samosa", 2, ist(2026, 11, 30, 10, 0))  # 3000
    place_paid(student, menu, "tea", 1, ist(2026, 11, 30, 11, 0))               # 1000
    place_paid(student, menu, "paneer_roll", 1, ist(2026, 11, 29, 11, 0))       # outside range

    inside_a.order_status = OrderStatus.COLLECTED
    db.session.commit()

    data = overview(client, "?from=2026-11-30&to=2026-11-30")

    assert data["paid_orders"] == 2
    assert data["gross_revenue_paise"] == 4000
    assert data["average_order_value_paise"] == 2000
    assert data["completion_rate_percent"] == 50.0


def test_unpaid_orders_inside_the_range_are_not_revenue(app, student, menu):
    from app.services.order_service import create_order

    client = admin(app)
    unpaid, _ = create_order(student.id, [{"menu_item_id": menu["tea"].id, "quantity": 1}])
    stored = db.session.get(Order, unpaid.id)
    stored.created_at = ist(2026, 11, 30, 12, 0)
    db.session.commit()

    data = overview(client, "?from=2026-11-30&to=2026-11-30")

    assert data["total_orders"] == 1
    assert data["paid_orders"] == 0
    assert data["gross_revenue_paise"] == 0


# ---------- Refund-adjusted reporting ----------

def test_partial_refund_reduces_net_revenue_on_the_orders_day(app, student, menu):
    client = admin(app)
    order = place_paid(student, menu, "samosa", 2, ist(2026, 11, 30, 12, 0))  # 3000
    add_refund(order, 1000)

    data = overview(client, "?from=2026-11-30&to=2026-11-30")
    days = sales(client, "?from=2026-11-30&to=2026-11-30")

    assert data["gross_revenue_paise"] == 3000
    assert data["refunded_paise"] == 1000
    assert data["net_revenue_paise"] == 2000
    assert days[0]["refunded_paise"] == 1000
    assert days[0]["revenue_paise"] == 3000


def test_refund_is_not_counted_until_razorpay_confirms_it(app, student, menu):
    client = admin(app)
    order = place_paid(student, menu, "samosa", 1, ist(2026, 11, 30, 12, 0))
    add_refund(order, 500, status=RefundStatus.PENDING)
    add_refund(order, 500, status=RefundStatus.FAILED)

    data = overview(client, "?from=2026-11-30&to=2026-11-30")

    assert data["refunded_paise"] == 0
    assert data["net_revenue_paise"] == 1500


def test_refund_belongs_to_the_day_of_its_order(app, student, menu):
    """A refund issued today for a 29th order still reduces the 29th, matching the report docs."""
    client = admin(app)
    order = place_paid(student, menu, "samosa", 2, ist(2026, 11, 29, 12, 0))
    add_refund(order, 1500)

    thirtieth = overview(client, "?from=2026-11-30&to=2026-11-30")
    twenty_ninth = overview(client, "?from=2026-11-29&to=2026-11-29")

    assert thirtieth["refunded_paise"] == 0
    assert twenty_ninth["refunded_paise"] == 1500
    assert twenty_ninth["net_revenue_paise"] == 1500


def test_popular_items_and_categories_respect_the_range(app, student, menu):
    client = admin(app)
    place_paid(student, menu, "samosa", 2, ist(2026, 11, 30, 10, 0))
    place_paid(student, menu, "tea", 5, ist(2026, 11, 29, 10, 0))

    items = client.get("/api/admin/reports/popular-items?from=2026-11-30&to=2026-11-30").get_json()["data"]["items"]
    categories = client.get("/api/admin/reports/categories?from=2026-11-30&to=2026-11-30").get_json()["data"]["categories"]

    assert [(item["item_name"], item["quantity"]) for item in items] == [("Samosa", 2)]
    assert [(row["category"], row["revenue_paise"]) for row in categories] == [("Snacks", 3000)]


def test_order_statistics_count_every_status_inside_the_range(app, student, menu):
    client = admin(app)
    place_paid(student, menu, "tea", 1, ist(2026, 11, 30, 9, 0))
    place_paid(student, menu, "tea", 1, ist(2026, 11, 29, 9, 0))

    data = client.get("/api/admin/reports/orders?from=2026-11-30&to=2026-11-30").get_json()["data"]

    assert data["total"] == 1
    assert data["by_payment_status"] == {"paid": 1}


# ---------- Limits ----------

def test_dates_at_the_calendar_limits_are_rejected_not_crashing(app):
    client = admin(app)

    for query in [
        "?from=9999-12-31&to=9999-12-31",   # the day after overflows the date type
        "?from=0001-01-01&to=0001-01-01",   # local midnight converts to year 0 in UTC
    ]:
        response = client.get(f"/api/admin/reports/overview{query}")
        assert response.status_code == 400, query
        assert response.get_json()["error"]["code"] == "INVALID_DATE", query


def test_single_date_without_its_partner_is_rejected(app):
    client = admin(app)

    response = client.get("/api/admin/reports/overview?from=2026-11-30")

    assert response.status_code == 400
    assert response.get_json()["error"]["code"] == "INVALID_DATE_RANGE"
