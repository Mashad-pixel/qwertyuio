# Fix notes

Before these fixes, `pytest` reported 34 failures. Now all 203 tests pass, `pyflakes` reports nothing,
and the migration chain builds a fresh database with no drift from the models.

## Bugs fixed in code

| File | Problem | Fix |
|---|---|---|
| `services/report_service.py` | `PAID_STATUSES` was used but never defined (`NameError` on every money report) | Constant restored |
| `services/razorpay_client.py` | Missing keys raised `RuntimeError`, so the API returned 500 | Raises `OrderError` (503 `PAYMENTS_NOT_CONFIGURED`) |
| `routes/payments.py` | `verify_checkout` was called with arguments in the wrong order, so every verify returned 404 | Arguments are now passed by name |
| `routes/payments.py` | `verify_checkout` returns a tuple, but the route treated it as an order | Route unpacks `(order, refund_required)`; a late payment returns 409 with the refund message |
| `services/payment_service.py` | `hmac.compare_digest` raises `TypeError` on non-ASCII signatures (500 instead of 400) | Non-ASCII input is rejected before comparing |
| `services/payment_service.py` | Missing webhook secret returned 400 instead of 503 | `WEBHOOKS_NOT_CONFIGURED` (503), same for checkout secret |
| `services/payment_service.py` | Webhook returned `True`/`False`, not the documented outcome | Returns `processed`, `ignored`, or `duplicate` |
| `services/refund_service.py` | Refund events with no refund ID were retried forever | Ignored (retrying can't help) |
| `routes/reports.py` | Report lists were returned as bare lists | Wrapped under `days`, `items`, `categories`, `hours` (the shape the tests and API docs use); peak-hours includes `timezone_offset_minutes` |
| `routes/auth.py` | Login clears the session, which also drops the CSRF token, so the next POST failed | Login and logout return a fresh `csrf_token` |

Unused imports were removed from several files.

## Test updates (the code was right, the tests were out of date)

- `test_orders.py`: error codes renamed to `MENU_ITEM_NOT_FOUND`, `QUANTITY_TOO_LARGE`, `INVALID_ITEMS`.
  Repeated menu items are now combined into one line (the documented design), not rejected.
- `test_payments.py`: bad Checkout signature returns `INVALID_SIGNATURE`; amount or owner mismatch returns 409 `PAYMENT_MISMATCH`.
- `test_refunds.py`: a refund webhook that arrives before its refund row is saved gets a 500 so Razorpay retries.
  The race test now checks the pending state before the retry. The unauthenticated test uses an anonymous client.
- `test_auth.py`: new test that login returns a CSRF token.

## Behavior decisions to confirm

1. **Captured payment for an unknown order** is now acknowledged (`ignored`, logged) instead of failing with 500.
   Otherwise Razorpay would retry it for about 24 hours with no way to fix it. Tell me if you want it to retry instead.
2. **Repeated menu items** are merged into one line, and the 20-unit limit applies to the combined quantity.
3. **Mismatch errors** return 409 (a conflict with the stored order), not 400.

## Setup after extracting

```powershell
pip install -r requirements.txt
flask --app run db upgrade
python -m pytest -v
```

Expected: `204 passed` (includes an end-to-end workflow test).

## Checkout details and kitchen collection

| File | Problem | Fix |
|---|---|---|
| `frontend/student/js/checkout.js` | The order request sent only the items. Name, phone and special instructions never reached the server. | The request now sends `customer_name`, `customer_phone` and `instructions`. Once the order exists, the form is locked, because those details are fixed on the order. A reused idempotency key after an edit starts a fresh order instead of retrying a 409. |
| `app/services/order_service.py` | Checkout details were not validated or stored. | Name (max 100) and instructions (max 500) are trimmed; blanks become null. Phone numbers must be 10-digit mobile numbers, with an optional +91, and are stored as `+91XXXXXXXXXX`. Invalid details return 400 `INVALID_CUSTOMER_DETAILS` and create nothing. |
| `app/models/order.py` | The `orders` table model did not have the columns the migration adds. | Added `customer_name`, `customer_phone`, `instructions` and `request_fingerprint`, matching migration `3f9a1c2b4d5e`. |
| `app/services/order_service.py` | A reused `Idempotency-Key` returned the first order even when the items or details were different. | Each order stores a SHA-256 fingerprint of its items and details. A retry with a different fingerprint returns 409 `IDEMPOTENCY_KEY_REUSED`. Orders created before fingerprints existed are compared by items. |
| `app/services/order_serializer.py` | The customer details were not returned. | `customer_name`, `customer_phone` and `instructions` are included in order responses. Firebase sync is unchanged and still omits them. |
| `frontend/kitchen/js/dashboard.js` | Ready tickets showed a "Confirm collection" button that the server always rejects with `USE_COLLECTION_FLOW`. | The button is removed. Ready tickets show "Hand over at the scanner", and collection is confirmed through the QR scanner only. |

Open item (not changed here): the migration history has four heads. Two branches both create `menu_categories` (`2b3c4d5e6f70` and `e1f2a3b4c5d6`), so `flask db upgrade` cannot run from an empty database. A merge revision alone is not enough. One of the two menu-category designs has to be chosen first. Until then the new order columns cannot be applied with the migration tool, and the test suite only checks the models through `create_all`.

## Kitchen board and order-success page

| File | Problem | Fix |
|---|---|---|
| `frontend/kitchen/js/dashboard.js`, `frontend/kitchen/dashboard.html` | "Confirm collection" button called an endpoint that always rejects manual collection. | Removed in the earlier change. Ready tickets say "Hand over at the scanner", and collection is confirmed only through the QR scanner. |
| `frontend/kitchen/dashboard.html`, `frontend/kitchen/js/dashboard.js`, `frontend/css/kitchen.css` | The Collected column and its count could never fill. The kitchen queue only returns orders that still need work, which `tests/test_kitchen.py` enforces. | Removed the Collected column, its count and its demo data. The board is three columns wide. The backend is unchanged. |
| `frontend/student/order-placed-animation.html`, `frontend/student/js/order-placed-animation.js` | The page showed a hard-coded burger with invented ingredients, "about 28 minutes", a rider on the way, a delivery box, and a random receipt number when none was passed. | Rebuilt around the real order. It loads `GET /api/orders/<id>` (or finds the order by receipt in the student's list), shows the real items, total and order number, and tracks the real stages: received, preparing, ready to collect, collected. It polls every 5 seconds until the order is collected or cancelled. Unpaid, cancelled, signed-out and not-found states each have their own message. The fake food and delivery content are gone. |
| `frontend/student/js/checkout.js`, `frontend/student/js/confirmation.js` | The success page had no order ID, so it could not load the order directly. | Both redirects now pass `order=<id>` alongside the receipt number. Stored orders without an ID still work through the lookup. |

Open item (not changed here): no student-facing page calls `GET /api/orders/<id>/collection-qr`. Students therefore have no way to show a collection code at the counter, so the QR scanner flow cannot be used end to end yet. The success page says "collect it at the counter" but cannot show the code, so this needs a follow-up.

## Admin orders: server-side paging, search and filters

| File | Problem | Fix |
|---|---|---|
| `frontend/admin/js/orders.js`, `frontend/admin/orders.html` | Search and filters ran only on the first 50 rows fetched once. Paging did not exist. The payment and status dropdowns sent display text ("Captured", "Received") that the server does not recognise. The rows read `status` and `total_amount`, which the server does not send. | Search, both filters and paging now go to `GET /api/admin/orders` with `q`, `payment_status`, `order_status`, `page` and `per_page=50`. Dropdowns use the server's values. Rows read `order_status`, `total_paise` and `student`. Previous/Next and a page counter were added. Typing is debounced. Responses from earlier requests are ignored once a newer one has started. Demo mode still works, with fixed sample rows filtered in the browser. |
| `app/services/order_query_service.py`, `app/routes/admin_orders.py` | No `q` search. `page` had no upper bound, so `page=10**20` reached the database and overflowed. | Added `q`: a case-insensitive match on order number, student name or student email. `%` and `_` match literally. Input is trimmed, blank means no search, and more than 100 characters returns 400 `INVALID_FILTER`. Added `MAX_PAGE = 10000`, which rejects larger pages with 400 `INVALID_PAGINATION`. |
| `tests/test_admin_order_search.py` | The test helper logged in without the server-side session token, so every request got 401 before reaching the code under test. | The helper now sets the session token with `issue_test_session`, as the other test helpers do. The test expectations are unchanged. |

`tests/test_order_query.py` could not be imported before because `MAX_PAGE` did not exist. It now imports and passes.

## Password recovery: email only, and actually connected

Found while fixing this: the recovery API was never registered with the app, so every forgot-password request returned 404. Its settings (`RECOVERY_*`, `SMTP_*`) were documented but never defined. The login page also sent requests without the CSRF token that production requires, and it read response fields from the wrong place.

| File | Problem | Fix |
|---|---|---|
| `frontend/student/js/student-login-page.js`, `frontend/student/login.html` | Forgot password and backup code accepted a mobile number and then promised a code by SMS. The registration hint promised an SMS code. Sign-in accepted a phone number and then rejected it. The server recovers accounts by email only. | Forgot password, backup code, sign-in and registration are email-only, matching the server. Copy no longer mentions mobile numbers or SMS. The OTP screen masks the email. "Contact support" still accepts a mobile number, because the server stores it for staff review, and its copy says so. |
| `frontend/student/js/student-login-page.js` | Recovery requests used raw `fetch` with no CSRF token, which production rejects. Error messages were read from an object and shown as "[object Object]". The reset token and support reference were read from the wrong place. | Requests go through the shared API client, which adds the CSRF token. Server messages are shown. The reset token and reference are read from the response data. |
| `app/__init__.py` | The recovery blueprint was never registered, so all forgot-password endpoints returned 404. | Registered `recovery_bp`. |
| `app/config.py` | `RECOVERY_*` and `SMTP_*` were used but not defined. The first code request would fail. | Defined them. Email (`smtp`) is the default. Development logs codes to the console. Tests use an in-memory outbox. Production uses SMTP. |
| `app/services/otp_delivery.py` | The in-memory outbox was not guarded, so it could run outside tests. | It is refused unless `ALLOW_MEMORY_DELIVERY` is set, which only tests set. Production refuses `console` and `memory`. |
| `app/services/account_recovery.py` | A password reset did not sign out existing sessions, even though its own comment and `CHANGES.md` say it does. | The reset revokes every session for the account in the same transaction as the password change. |
| `tests/test_recovery.py` | Session setup omitted the `sid` token, so requests returned 401. | Uses `issue_test_session`, as the other test helpers do. Expectations are unchanged. |

Why not add SMS recovery: accounts have no phone number, so a mobile number cannot identify an account. Adding it would need an SMS provider and a phone-to-account link. Those are product decisions.

Before recovery emails can reach students, the deployment needs `SMTP_HOST`, `SMTP_PORT`, `SMTP_USERNAME`, `SMTP_PASSWORD`, `SMTP_FROM` and `RECOVERY_DELIVERY=smtp`. Without them, codes are not sent, and the failure is logged.
