// Canteen ordering switch. The server stores whether students can order and the message they see when
// ordering is closed. Nothing on this page is saved in the browser.
(function () {
  "use strict";

  const content = document.querySelector(".admin-content");
  let status = null;   // { is_accepting_orders, message } from the server
  let busy = false;
  let notice = null;

  function el(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }

  function errorText(error) {
    if (error && error.data && error.data.details && typeof error.data.details === "object") {
      const first = Object.values(error.data.details)[0];
      if (first) return String(first);
    }
    if (error && typeof error.status !== "number") return "Could not reach the server. Nothing was changed.";
    return (error && error.message) || "Something went wrong. Nothing was changed.";
  }

  function orderingCard() {
    const open = status.is_accepting_orders;
    const card = el("section", undefined, "card");
    card.style.cssText = "max-width:620px;margin-top:22px;padding:22px";
    card.appendChild(el("h2", "Ordering"));
    card.appendChild(el("p", open ? "Open. Students can place orders." : "Closed. Students cannot place orders.",
      open ? "status" : "status danger"));
    if (!open && status.message) {
      card.appendChild(el("p", `Students see: “${status.message}”`, "ui-muted"));
    }

    const label = el("label", undefined, "field");
    label.appendChild(el("span", "Message to students when ordering is closed (optional)"));
    const message = el("textarea");
    message.name = "closed_message";
    message.maxLength = 200;
    message.value = status.message || "";
    message.placeholder = "For example: Closed for exams until Monday";
    message.disabled = busy;
    label.appendChild(message);
    card.appendChild(label);

    const toggle = el("button", open ? "Stop taking orders" : "Start taking orders", "btn btn-primary");
    toggle.type = "button";
    toggle.id = "toggle-ordering";
    toggle.disabled = busy;
    const actions = el("div", undefined, undefined);
    actions.style.marginTop = "14px";
    actions.appendChild(toggle);
    card.appendChild(actions);
    return card;
  }

  function hoursNoticeCard() {
    const card = el("section", undefined, "card");
    card.style.cssText = "max-width:620px;margin-top:18px;padding:22px";
    card.appendChild(el("h2", "Name and opening hours"));
    card.appendChild(el("p",
      "The canteen name and opening hours are not stored in the system yet, so they are not shown here. Use the switch above to stop or start orders.",
      "ui-muted"));
    return card;
  }

  function render() {
    content.replaceChildren(
      el("h1", "Canteen settings", "admin-title"),
      el("p", "This switch decides whether students can place orders. Changes apply immediately.", "ui-muted"),
      ...(notice ? [notice] : []),
      orderingCard(),
      hoursNoticeCard()
    );
  }

  function say(text, tone) {
    notice = el("div", text, tone === "danger" ? "card status danger" : "card status");
    notice.style.cssText = "margin:14px 0;padding:12px 16px;max-width:620px";
    render();
    setTimeout(() => { notice = null; render(); }, 5000);
  }

  async function reloadStatus() {
    status = await trayApi.get("/canteen/status");
  }

  async function load() {
    try {
      await reloadStatus();
      render();
    } catch (error) {
      content.replaceChildren(el("h1", "Canteen settings", "admin-title"),
        el("div", errorText(error), "card status danger"));
    }
  }

  async function setOrdering(open, closedMessage) {
    if (busy) return;
    busy = true;
    render();
    try {
      const body = open
        ? { is_accepting_orders: true }
        : { is_accepting_orders: false, closed_message: closedMessage || null };
      await trayApi.patch("/admin/canteen/status", body);
      await reloadStatus();
      busy = false;
      say(open ? "Students can order again." : "Ordering is closed for students.", "ok");
    } catch (error) {
      busy = false;
      say(errorText(error), "danger");
      try { await reloadStatus(); } catch (_) {}
    }
  }

  content.addEventListener("click", (event) => {
    if (!event.target.closest("#toggle-ordering") || !status) return;
    const messageBox = content.querySelector('textarea[name="closed_message"]');
    setOrdering(!status.is_accepting_orders, messageBox ? messageBox.value.trim() : "");
  });

  load();
})();
