(function () {
  // Categories are not managed here yet. Menu items keep the category names they already have.
  const content = document.querySelector(".admin-content");
  content.innerHTML = '<h1 class="admin-title">Categories</h1>' +
    '<div class="card" style="margin-top:22px;padding:22px"><strong>Not connected to the live system yet.</strong>' +
    '<p style="color:var(--muted);margin-top:8px">Category management needs a server-side category list. Until it exists, nothing is saved from this page.</p></div>';
})();
